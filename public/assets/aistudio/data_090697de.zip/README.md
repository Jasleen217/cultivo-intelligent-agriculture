# 🌾 Krishi Mandi Price Prediction & Crop Suggestion Platform
**BTech CSE Final Year / Major Project (2026)**

A clean, beginner-friendly Web Application designed for Indian farmers to check current APMC mandi rates, view 30-day price predictions, and receive tailored crop recommendations based on soil type, season, and land area.

---

## 🎯 Project Objectives
1. **Price Transparency**: Help farmers view real-time auction rates from nearby APMC mandis.
2. **Price Prediction**: Provide a 30-day forecast so farmers know if prices are expected to rise or fall.
3. **Selling Recommendation**: Advise farmers whether to **Sell Immediately** or **Hold for 3-4 Weeks** in storage to maximize profits.
4. **Crop Recommendation**: Suggest the top 4 most suitable and profitable crops matching the farmer's soil and season.

---

## 💻 Tech Stack (Simple & Explainable)
- **Frontend**:
  - `HTML5`: Semantic structure, clean forms, and normal HTML tables.
  - `CSS3`: Clean green and white theme (`#2e7d32`), card layouts, and responsive design.
  - `JavaScript (ES6)`: Fetch API for calling backend routes, DOM manipulation (`innerHTML`), and HTML5 Canvas API (`getContext('2d')`) for the price chart.
- **Backend**:
  - `Node.js`: Lightweight HTTP server and REST APIs without external dependencies.
- **Data Model**:
  - Structured datasets covering 9 Indian states, 14 major agricultural crops, and 6 soil types.

---

## 📁 Project Directory Structure
```
krishi-mandi-platform/
├── data/
│   ├── crops.js         # Crops database, MSP benchmarks, base prices, agronomy
│   ├── locations.js     # 9 Indian agricultural states, districts & mandis
│   └── soils.js         # 6 Indian soil classifications & characteristics
├── services/
│   ├── advisoryEngine.js    # Sell vs Hold logic based on carrying costs
│   ├── arbitrageEngine.js   # Nearby mandis distance & transport calculation
│   ├── predictionEngine.js  # 30-90 days price forecasting logic
│   └── recommendationEngine.js # Soil & season crop scoring algorithm
├── public/
│   ├── css/
│   │   └── style.css    # Clean Green & White theme stylesheet
│   ├── js/
│   │   └── app.js       # Student-friendly JavaScript (fetch, DOM, Canvas chart)
│   └── index.html       # Single-page clean interface with navbar & about section
├── server.js            # Node.js backend server
├── start.bat            # 1-click Windows runner script
├── test.js              # Unit tests for verification
└── README.md            # Project documentation & viva guide
```

---

## 🚀 How to Run the Project
1. Open PowerShell / Command Prompt in the project folder:
   ```powershell
   cd C:\Users\HP\.gemini\antigravity\scratch\krishi-mandi-platform
   ```
2. Start the website:
   ```powershell
   node server.js
   ```
3. Open your browser and go to:
   ```
   http://localhost:3000
   ```

---

## 🎓 Teacher / Viva Presentation Guide

### Question 1: "What is the system architecture of your project?"
**Answer**:
> "Sir/Ma'am, this project follows a classic **3-Tier Web Architecture**:
> 1. **Client Tier (Presentation)**: Built with HTML5, CSS3, and JavaScript. It gathers farmer inputs and displays price tables, cards, and an HTML5 canvas chart.
> 2. **Application Tier (Logic)**: A Node.js backend running REST APIs (`/api/mandi/nearby`, `/api/crop/recommend`, `/api/mandi/forecast`, `/api/insights/selling-period`).
> 3. **Data Tier (Storage)**: Modular JSON-based datasets containing APMC locations, crop agronomy parameters, and soil compatibility matrices."

### Question 2: "How does the Crop Recommendation algorithm work?"
**Answer**:
> "The recommendation engine uses a **Multi-Criteria Decision Matrix** with 4 weighted factors:
> - Soil Compatibility (35% weight)
> - Season Match (30% weight)
> - Water Availability (20% weight)
> - Cultivation Budget (15% weight)
> The system calculates a score out of 100 for each candidate crop and displays the top 4 crops with their expected yield and net profit."

### Question 3: "How is the price chart drawn without Chart.js or React?"
**Answer**:
> "We use the native **HTML5 Canvas API** (`getContext('2d')`). In `app.js`, the `drawPriceChart()` function scales prices to canvas coordinates using basic linear interpolation and draws historical prices in green and predicted future prices in blue using `ctx.beginPath()`, `ctx.moveTo()`, and `ctx.lineTo()`."

### Question 4: "How does the Selling Recommendation decide between Sell vs. Hold?"
**Answer**:
> "It calculates the difference between today's market price and the predicted 30-day price, and then subtracts monthly warehouse storage costs (approx ₹25/quintal/month). If the expected price rise exceeds the storage cost, it recommends **HOLD FOR 3-4 WEEKS**; otherwise, it advises **SELL TODAY**."
