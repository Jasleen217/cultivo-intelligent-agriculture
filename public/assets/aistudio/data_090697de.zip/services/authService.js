// AgriGreen Authentication Service
// Manages Farmer Registration, Password Hashing, Validation, and Sessions

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const USERS_FILE = path.join(__dirname, '..', 'data', 'users.json');

// Ensure users.json exists
if (!fs.existsSync(USERS_FILE)) {
  fs.writeFileSync(USERS_FILE, JSON.stringify([], null, 2), 'utf-8');
}

// Active session store: sessionId -> { userId, email, fullName, mobile, expiresAt }
const activeSessions = new Map();

/**
 * Load users from users.json
 */
function loadUsers() {
  try {
    const raw = fs.readFileSync(USERS_FILE, 'utf-8');
    return JSON.parse(raw || '[]');
  } catch (err) {
    console.error('Error reading users file:', err);
    return [];
  }
}

/**
 * Save users to users.json
 */
function saveUsers(users) {
  try {
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error('Error writing users file:', err);
    return false;
  }
}

/**
 * Secure password hashing using salt and cryptographic scrypt / pbkdf2
 */
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt$${salt}$${hash}`;
}

/**
 * Verify provided password against stored hash
 */
function verifyPassword(password, storedHash) {
  if (!storedHash || !password) return false;

  // Support scrypt format: scrypt$salt$hash
  if (storedHash.startsWith('scrypt$')) {
    const parts = storedHash.split('$');
    if (parts.length !== 3) return false;
    const salt = parts[1];
    const originalHash = parts[2];
    const computedHash = crypto.scryptSync(password, salt, 64).toString('hex');
    return crypto.timingSafeEqual(Buffer.from(originalHash, 'hex'), Buffer.from(computedHash, 'hex'));
  }

  // Fallback for bcrypt if previously hashed with bcrypt
  try {
    const bcrypt = require('bcryptjs');
    return bcrypt.compareSync(password, storedHash);
  } catch (e) {
    return false;
  }
}

/**
 * Register a new farmer
 */
function registerUser({ fullName, mobile, email, password, confirmPassword }) {
  // Input validations
  if (!fullName || !fullName.trim()) {
    return { success: false, error: 'Full name is required.' };
  }
  if (!mobile || !/^[0-9]{10}$/.test(mobile.trim())) {
    return { success: false, error: 'Please enter a valid 10-digit mobile number.' };
  }
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
    return { success: false, error: 'Please enter a valid email address.' };
  }
  if (!password || password.length < 6) {
    return { success: false, error: 'Password must be at least 6 characters long.' };
  }
  if (password !== confirmPassword) {
    return { success: false, error: 'Passwords do not match.' };
  }

  const users = loadUsers();
  const normalizedEmail = email.trim().toLowerCase();

  // Check for duplicate registration
  const existingUser = users.find(u => u.email.toLowerCase() === normalizedEmail);
  if (existingUser) {
    return { success: false, error: 'An account with this email address already exists. Please login instead.' };
  }

  // Create new user record
  const newUser = {
    id: `farmer_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    fullName: fullName.trim(),
    mobile: mobile.trim(),
    email: normalizedEmail,
    password: hashPassword(password),
    createdAt: new Date().toISOString()
  };

  users.push(newUser);
  saveUsers(users);

  return {
    success: true,
    user: {
      id: newUser.id,
      fullName: newUser.fullName,
      email: newUser.email,
      mobile: newUser.mobile
    }
  };
}

/**
 * Authenticate login credentials
 */
function loginUser({ email, password, rememberMe }) {
  if (!email || !password) {
    return { success: false, error: 'Email and password are required.' };
  }

  const users = loadUsers();
  const normalizedEmail = email.trim().toLowerCase();
  const user = users.find(u => u.email.toLowerCase() === normalizedEmail);

  if (!user || !verifyPassword(password, user.password)) {
    return { success: false, error: 'Invalid email address or password. Please try again.' };
  }

  // Create active session
  const sessionId = crypto.randomBytes(32).toString('hex');
  const durationMs = rememberMe ? (7 * 24 * 60 * 60 * 1000) : (24 * 60 * 60 * 1000); // 7 days vs 1 day
  const expiresAt = Date.now() + durationMs;

  const sessionData = {
    userId: user.id,
    fullName: user.fullName,
    email: user.email,
    mobile: user.mobile,
    expiresAt: expiresAt
  };

  activeSessions.set(sessionId, sessionData);

  return {
    success: true,
    sessionId: sessionId,
    expiresAt: expiresAt,
    user: {
      id: user.id,
      fullName: user.fullName,
      email: user.email,
      mobile: user.mobile
    }
  };
}

/**
 * Verify session token
 */
function getSession(sessionId) {
  if (!sessionId) return null;
  const session = activeSessions.get(sessionId);
  if (!session) return null;

  if (Date.now() > session.expiresAt) {
    activeSessions.delete(sessionId);
    return null;
  }

  return session;
}

/**
 * Destroy session (logout)
 */
function destroySession(sessionId) {
  if (sessionId) {
    activeSessions.delete(sessionId);
  }
  return true;
}

module.exports = {
  registerUser,
  loginUser,
  getSession,
  destroySession,
  loadUsers
};
