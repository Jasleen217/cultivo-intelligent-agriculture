// Multi-Factor Crop Recommendation Engine
// Matches Soil Type, Season, Irrigation, Land Size, and Budget to rank most profitable & viable crops

const CROPS = require('../data/crops');
const { SOILS, SEASONS } = require('../data/soils');

/**
 * Calculates a crop suitability score (0-100) and detailed financial return metrics
 */
function recommendCrops({
  stateId = "MH",
  soilType = "Black",
  season = "Rabi",
  landSizeAcres = 5,
  irrigation = "Tube-well",
  budget = "Moderate"
}) {
  const selectedSoil = SOILS.find(s => s.id === soilType) || SOILS[0];
  const selectedSeason = SEASONS.find(s => s.id === season) || SEASONS[0];

  const recommendations = CROPS.map(crop => {
    let score = 50; // base score

    // 1. Season Match (Crucial 30 points)
    const isSeasonMatch = crop.seasons.includes(season);
    if (isSeasonMatch) {
      score += 30;
    } else {
      score -= 35; // penalty if wrong season
    }

    // 2. Soil Match (25 points)
    const isOptimalSoil = crop.optimalSoil.some(s => s.toLowerCase().includes(soilType.toLowerCase()) || soilType.toLowerCase().includes(s.toLowerCase()));
    if (isOptimalSoil) {
      score += 25;
    } else if (selectedSoil.recommendedCrops.includes(crop.id)) {
      score += 20;
    } else {
      score -= 10;
    }

    // 3. Irrigation & Water Requirement Match (20 points)
    if (irrigation === "Rainfed") {
      if (crop.waterNeed === "Low") score += 20;
      else if (crop.waterNeed === "Moderate") score += 5;
      else if (crop.waterNeed === "High") score -= 30; // Cannot grow paddy/sugarcane/tomato rainfed
    } else if (irrigation === "Drip/Sprinkler") {
      if (crop.waterNeed === "High" || crop.waterNeed === "Moderate") score += 20;
      else score += 15;
    } else { // Canal or Tube-well
      score += 15;
    }

    // 4. Budget & Capital Match (15 points)
    if (budget === "Low") {
      if (crop.cultivationCostAcre <= 15000) score += 15;
      else if (crop.cultivationCostAcre > 30000) score -= 20; // onion, garlic, tomato are high capital
    } else if (budget === "High") {
      // High capital allows high-value cash crops
      if (crop.cultivationCostAcre > 25000) score += 15;
      else score += 10;
    } else { // Moderate
      score += 12;
    }

    // Clamp score between 10 and 99
    score = Math.max(12, Math.min(98, Math.round(score)));

    // Financial projections based on farmer's acreage
    const yieldPerAcre = crop.typicalYieldAcre.avg;
    const totalYieldQuintals = Math.round(yieldPerAcre * landSizeAcres);
    const costPerAcre = crop.cultivationCostAcre;
    const totalCost = Math.round(costPerAcre * landSizeAcres);
    const expectedRatePerQtl = crop.baseModalPrice;
    const grossRevenuePerAcre = Math.round(yieldPerAcre * expectedRatePerQtl);
    const totalGrossRevenue = Math.round(totalYieldQuintals * expectedRatePerQtl);
    const netProfitPerAcre = grossRevenuePerAcre - costPerAcre;
    const totalNetProfit = totalGrossRevenue - totalCost;
    const roiPercent = Math.round((netProfitPerAcre / costPerAcre) * 100);

    // Risk level
    let riskLevel = "Moderate";
    let riskLevelHi = "मध्यम";
    if (crop.volatility > 0.35 || crop.waterNeed === "High") {
      riskLevel = "High Volatility / High Return";
      riskLevelHi = "उच्च उतार-चढ़ाव / अधिक लाभ";
    } else if (crop.msp2025 > 0 && crop.volatility < 0.20) {
      riskLevel = "Low Risk (Protected by MSP)";
      riskLevelHi = "कम जोखिम (MSP सुरक्षित)";
    }

    return {
      cropId: crop.id,
      name: crop.name,
      nameHi: crop.nameHi,
      category: crop.category,
      categoryHi: crop.categoryHi,
      score: score,
      yieldPerAcre: yieldPerAcre,
      totalYieldQuintals: totalYieldQuintals,
      costPerAcre: costPerAcre,
      totalCost: totalCost,
      expectedRatePerQtl: expectedRatePerQtl,
      grossRevenuePerAcre: grossRevenuePerAcre,
      totalGrossRevenue: totalGrossRevenue,
      netProfitPerAcre: netProfitPerAcre,
      totalNetProfit: totalNetProfit,
      roiPercent: roiPercent,
      waterNeed: crop.waterNeed,
      riskLevel: riskLevel,
      riskLevelHi: riskLevelHi,
      durationDays: crop.durationDays,
      sowingWindow: crop.sowingWindow,
      fertilizerGuidance: crop.fertilizerGuidance,
      msp: crop.msp2025 || crop.msp2024 || 0,
      marketInsightSummary: crop.marketInsightSummary
    };
  });

  // Sort by suitability score descending, then by net profit
  recommendations.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    return b.netProfitPerAcre - a.netProfitPerAcre;
  });

  return {
    farmerProfile: {
      soilType: selectedSoil.name,
      soilTypeHi: selectedSoil.nameHi,
      season: selectedSeason.name,
      landSizeAcres: landSizeAcres,
      irrigation: irrigation,
      budget: budget
    },
    soilDetails: selectedSoil,
    topCrops: recommendations.slice(0, 5), // Top 5 recommended crops
    allRankedCrops: recommendations
  };
}

module.exports = {
  recommendCrops
};
