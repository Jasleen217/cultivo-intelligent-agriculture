// AI Selling-Period Advisory Engine (Sell Now vs Hold Decision Engine)
// Computes financial trade-off: Future Price Gain vs Warehouse Storage, Spoilage, and Capital Interest Costs

const CROPS = require('../data/crops');
const { generatePriceHistoryAndForecast } = require('./predictionEngine');

/**
 * Evaluates whether a farmer should sell their harvest today or hold in storage
 */
function generateSellingPeriodAdvisory(cropId, mandiId, storageOption = "warehouse", holdingTargetDays = 30) {
  const crop = CROPS.find(c => c.id === cropId) || CROPS[0];
  const priceData = generatePriceHistoryAndForecast(cropId, mandiId);
  const currentPrice = priceData.currentPrices.modalPrice;

  // Find forecasted price at target days
  const targetPoint = priceData.forecastPoints.find(p => p.daysAhead === holdingTargetDays) || 
                      priceData.forecastPoints[Math.min(holdingTargetDays, priceData.forecastPoints.length - 1)];
  const predictedPrice = targetPoint.modalPrice;
  const projectedPriceDelta = predictedPrice - currentPrice;

  // Monthly carrying cost breakdown (per Quintal)
  const holdingMonths = holdingTargetDays / 30;
  
  // Storage fee: warehouse vs cold storage vs on-farm
  let storageCostPerMonth = crop.storageCostPerQtlMonth;
  if (storageOption === "onFarm") {
    storageCostPerMonth = Math.round(storageCostPerMonth * 0.45); // Neem oil treatment + bags
  } else if (storageOption === "coldStorage") {
    storageCostPerMonth = Math.max(storageCostPerMonth, 50);
  }

  const totalStorageFee = Math.round(storageCostPerMonth * holdingMonths);

  // Spoilage & moisture shrinkage loss (per Quintal value)
  const spoilageRate = (crop.storageLossPercentPerMonth / 100) * holdingMonths;
  const spoilageCost = Math.round(currentPrice * spoilageRate);

  // Opportunity cost of capital (Kisan Credit Card loan interest ~ 7% p.a. = 0.58% per month)
  const capitalCostRate = (0.07 / 12) * holdingMonths;
  const capitalHoldingCost = Math.round(currentPrice * capitalCostRate);

  const totalCarryingCost = totalStorageFee + spoilageCost + capitalHoldingCost;
  const netProfitOrLossPerQtl = projectedPriceDelta - totalCarryingCost;

  // Decision logic
  let actionVerdict = "SELL_NOW";
  let actionTitleEn = "SELL TODAY (मार्केट में आज ही बेचें)";
  let actionTitleHi = "आज ही बेचें (सर्वोत्तम भाव)";
  let riskAssessment = "LOW";
  let badgeColor = "emerald";

  if (netProfitOrLossPerQtl >= 120) {
    actionVerdict = "HOLD";
    actionTitleEn = `HOLD FOR ${holdingTargetDays} DAYS (रोक कर रखें)`;
    actionTitleHi = `${holdingTargetDays} दिनों के लिए भंडारित करें`;
    badgeColor = "amber";
    riskAssessment = crop.volatility > 0.3 ? "MODERATE_HIGH" : "LOW_RISK";
  } else if (netProfitOrLossPerQtl >= 40 && netProfitOrLossPerQtl < 120) {
    actionVerdict = "STAGGERED_SELL";
    actionTitleEn = "STAGGERED SELLING (50% NOW, 50% LATER)";
    actionTitleHi = "आधा आज बेचें, आधा रोकें (50-50 रणनीति)";
    badgeColor = "blue";
    riskAssessment = "MODERATE";
  } else {
    actionVerdict = "SELL_NOW";
    actionTitleEn = "SELL IMMEDIATELY (तुरंत बेचें)";
    actionTitleHi = "तुरंत मंडी में बेचें";
    badgeColor = "rose";
    riskAssessment = "HIGH_HOLDING_RISK";
  }

  // Detailed AI natural language explanation in English and Hindi
  let narrativeEn = "";
  let narrativeHi = "";

  if (actionVerdict === "HOLD") {
    narrativeEn = `Our predictive market model forecasts that ${crop.name} prices will rise from ₹${currentPrice} to approximately ₹${predictedPrice}/Qtl over the next ${holdingTargetDays} days (+₹${projectedPriceDelta}). After deducting storage charges (₹${totalStorageFee}), natural shrinkage/spoilage (₹${spoilageCost}), and interest costs (₹${capitalHoldingCost}), your net estimated gain is +₹${netProfitOrLossPerQtl} per quintal. Holding in certified warehouse/e-NWR is recommended.`;
    narrativeHi = `हमारा मार्केट प्रेडिक्शन मॉडल दर्शाता है कि आगामी ${holdingTargetDays} दिनों में ${crop.nameHi} के दाम ₹${currentPrice} से बढ़कर लगभग ₹${predictedPrice}/क्विंटल (+₹${projectedPriceDelta}) होने की संभावना है। भंडारण शुल्क (₹${totalStorageFee}), नमी व सूख नुकसान (₹${spoilageCost}) और ब्याज लागत (₹${capitalHoldingCost}) घटाने के बाद भी आपको प्रति क्विंटल शुद्ध +₹${netProfitOrLossPerQtl} का अतिरिक्त मुनाफा मिलेगा। अतः फसल को वेयरहाउस में सुरक्षित रखना अधिक लाभकारी है।`;
  } else if (actionVerdict === "STAGGERED_SELL") {
    narrativeEn = `The price trajectory is slightly positive (+₹${projectedPriceDelta}/Qtl), but after factoring in carrying costs of ₹${totalCarryingCost}/Qtl, your net margin is only +₹${netProfitOrLossPerQtl}. We strongly advise staggered liquidation: sell 50% of your produce now to recover production investment and eliminate immediate liquidity stress, while holding 50% for 30-45 days to capture any upside price spikes.`;
    narrativeHi = `भाव में हल्की बढ़ोतरी (+₹${projectedPriceDelta}/क्विंटल) की उम्मीद है, लेकिन ₹${totalCarryingCost} का कुल भंडारण खर्च निकालने के बाद शुद्ध लाभ केवल +₹${netProfitOrLossPerQtl} ही बचता है। जोखिम से बचने के लिए 50-50 फॉर्मूला अपनाएं: आधी उपज आज बेचकर लागत निकालें और शेष आधी फसल को 30-45 दिन रोककर ऊंचे भाव का लाभ उठाएं।`;
  } else {
    narrativeEn = `Current mandi arrivals are strong and prices are currently near their seasonal equilibrium at ₹${currentPrice}/Qtl. Holding this produce will incur storage fees, moisture loss, and quality degradation totaling ₹${totalCarryingCost}/Qtl, resulting in a net negative return of ₹${netProfitOrLossPerQtl}/Qtl. Delaying sales is not financially justified. Selling in the active spot market today will maximize your net pocket realization.`;
    narrativeHi = `वर्तमान में मंडी भाव ₹${currentPrice}/क्विंटल पर स्थिर हैं। फसल को रोकने पर भंडारण शुल्क, नमी सूख और सड़न का कुल खर्च ₹${totalCarryingCost}/क्विंटल आएगा, जिससे आपको प्रति क्विंटल ₹${Math.abs(netProfitOrLossPerQtl)} का शुद्ध घाटा हो सकता है। अतः माल को रोकने के बजाय आज ही नजदीकी सर्वोत्तम मंडी में बेचना सबसे समझदारी भरा निर्णय है।`;
  }

  // Key actionable market catalysts
  const catalysts = [
    {
      titleEn: "Arrivals & Supply Pressure",
      titleHi: "मंडी आवक व आपूर्ति",
      detailEn: `${priceData.currentPrices.arrivalsTonnes} tonnes daily volume. Peak arrivals expected to taper over the next 3 weeks.`,
      detailHi: `दैनिक आवक ${priceData.currentPrices.arrivalsTonnes} टन। अगले 3 हफ्तों में आवक कम होने की संभावना।`
    },
    {
      titleEn: "Govt MSP Safety Net",
      titleHi: "सरकारी न्यूनतम समर्थन मूल्य (MSP)",
      detailEn: crop.msp2025 > 0 ? `Current market rate is ${priceData.currentPrices.mspDifference >= 0 ? '+' : ''}₹${priceData.currentPrices.mspDifference} (${priceData.currentPrices.mspDifferencePercent}%) relative to MSP (₹${crop.msp2025}/Qtl).` : "No MSP mechanism applies; purely driven by open wholesale supply and demand.",
      detailHi: crop.msp2025 > 0 ? `वर्तमान भाव सरकारी MSP (₹${crop.msp2025}/क्विंटल) से ${priceData.currentPrices.mspDifference >= 0 ? '+' : ''}₹${priceData.currentPrices.mspDifference} (${priceData.currentPrices.mspDifferencePercent}%) पर चल रहा है।` : "इस फसल पर MSP लागू नहीं है; दाम पूर्णतः थोक मांग व आपूर्ति पर निर्भर हैं।"
    },
    {
      titleEn: "Weather & Quality Warning",
      titleHi: "मौसम एवं फसल गुणवत्ता चेतावनी",
      detailEn: `Ensure moisture level is strictly under 12% before storage to prevent aflatoxin and fungal spoilage in warehouse.`,
      detailHi: `वेयरहाउस में भंडारण से पहले नमी 12% से कम रखें ताकि फफूंद और वजन ह्रास से उपज सुरक्षित रहे।`
    }
  ];

  return {
    verdict: actionVerdict,
    badgeColor: badgeColor,
    riskAssessment: riskAssessment,
    holdingTargetDays: holdingTargetDays,
    storageOption: storageOption,
    titleEn: actionTitleEn,
    titleHi: actionTitleHi,
    narrativeEn: narrativeEn,
    narrativeHi: narrativeHi,
    financials: {
      currentPrice: currentPrice,
      predictedPrice: predictedPrice,
      grossPriceDelta: projectedPriceDelta,
      storageFee: totalStorageFee,
      spoilageCost: spoilageCost,
      capitalInterestCost: capitalHoldingCost,
      totalCarryingCost: totalCarryingCost,
      netProfitOrLossPerQtl: netProfitOrLossPerQtl
    },
    catalysts: catalysts
  };
}

module.exports = {
  generateSellingPeriodAdvisory
};
