// Nearby Mandi Price Comparison & Arbitrage Economics Engine
// Calculates real-time price differentials, transport logistics, and net realized farmer profits

const LOCATIONS = require('../data/locations');
const CROPS = require('../data/crops');

// Vehicle specs for transport cost calculation
const VEHICLES = {
  tractor: {
    name: "Tractor Trolley",
    nameHi: "ट्रैक्टर ट्रॉली",
    capacityQuintals: 50,
    costPerKm: 24, // ₹ per km roundtrip
    handlingPerQtl: 12 // Loading/unloading
  },
  pickup: {
    name: "Pickup Truck (Bolero Maxi / Dost)",
    nameHi: "पिकअप ट्रक",
    capacityQuintals: 25,
    costPerKm: 18,
    handlingPerQtl: 12
  },
  largeTruck: {
    name: "10-Wheeler Commercial Truck",
    nameHi: "बड़ा ट्रक (10 चक्का)",
    capacityQuintals: 150,
    costPerKm: 38,
    handlingPerQtl: 10
  }
};

/**
 * Calculates haversine approximate distance in KM between two coordinates
 */
function calculateDistanceKm(lat1, lon1, lat2, lon2) {
  const R = 6371; // Earth radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return Math.round(R * c);
}

/**
 * Finds all mandis within state or adjacent regions
 */
function getNearbyMandis(stateId, districtId, currentMandiId, cropId, vehicleType = 'pickup', loadQuintals = 25) {
  const crop = CROPS.find(c => c.id === cropId) || CROPS[0];
  const vehicle = VEHICLES[vehicleType] || VEHICLES.pickup;

  // Locate current state and mandi
  const state = LOCATIONS.states.find(s => s.id === stateId) || LOCATIONS.states[0];
  let currentMandi = null;
  let allStateMandis = [];

  for (const dist of state.districts) {
    for (const m of dist.mandis) {
      allStateMandis.push({ ...m, districtName: dist.name, districtNameHi: dist.nameHi, stateName: state.name });
      if (m.id === currentMandiId) {
        currentMandi = { ...m, districtName: dist.name, districtNameHi: dist.nameHi, stateName: state.name };
      }
    }
  }

  // If current mandi not found, pick the first
  if (!currentMandi) {
    currentMandi = allStateMandis[0];
  }

  // Also include a few notable mandis from neighboring states if list is small
  if (allStateMandis.length < 5) {
    for (const otherState of LOCATIONS.states) {
      if (otherState.id !== state.id) {
        for (const dist of otherState.districts) {
          for (const m of dist.mandis) {
            allStateMandis.push({ ...m, districtName: dist.name, districtNameHi: dist.nameHi, stateName: otherState.name });
            if (allStateMandis.length >= 8) break;
          }
          if (allStateMandis.length >= 8) break;
        }
      }
      if (allStateMandis.length >= 8) break;
    }
  }

  // Calculate distance, prices and net margins for each mandi
  const results = allStateMandis.map(mandi => {
    let distance = 0;
    if (mandi.id === currentMandi.id) {
      distance = 0;
    } else {
      distance = calculateDistanceKm(currentMandi.lat, currentMandi.lon, mandi.lat, mandi.lon);
      if (distance === 0) distance = mandi.distanceOffset || 25;
    }

    // Pseudo-deterministic price adjustment per mandi based on distance and type
    const hash = (mandi.id + crop.id).split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const variancePercent = ((hash % 17) - 8) * 0.012; // -9% to +10%
    const modalPrice = Math.round(crop.baseModalPrice * (1 + variancePercent));
    const minPrice = Math.round(modalPrice * 0.93);
    const maxPrice = Math.round(modalPrice * 1.07);

    // Transport calculation: roundtrip distance * vehicle cost per km / load size
    const effectiveLoad = Math.min(loadQuintals, vehicle.capacityQuintals);
    const roundTripDistance = distance * 2;
    const totalFreightCost = roundTripDistance * vehicle.costPerKm;
    const freightCostPerQtl = distance === 0 ? 0 : Math.round(totalFreightCost / effectiveLoad);
    const mandiCessAndLaborPerQtl = distance === 0 ? 10 : (vehicle.handlingPerQtl + 8); // APMC tax + unloading
    const totalDeductionsPerQtl = freightCostPerQtl + mandiCessAndLaborPerQtl;
    const netRealizedPrice = modalPrice - totalDeductionsPerQtl;

    return {
      id: mandi.id,
      name: mandi.name,
      nameHi: mandi.nameHi,
      districtName: mandi.districtName,
      districtNameHi: mandi.districtNameHi,
      stateName: mandi.stateName,
      type: mandi.type,
      distanceKm: distance,
      modalPrice: modalPrice,
      minPrice: minPrice,
      maxPrice: maxPrice,
      freightCostPerQtl: freightCostPerQtl,
      mandiFeesPerQtl: mandiCessAndLaborPerQtl,
      totalDeductionsPerQtl: totalDeductionsPerQtl,
      netRealizedPrice: netRealizedPrice,
      isHomeMandi: mandi.id === currentMandi.id
    };
  });

  // Sort by net realized price (highest first)
  results.sort((a, b) => b.netRealizedPrice - a.netRealizedPrice);

  // Identify home mandi and top winner
  const homeMandi = results.find(m => m.isHomeMandi) || results[0];
  const bestMandi = results[0];

  const netGainVsHomePerQtl = bestMandi.netRealizedPrice - homeMandi.netRealizedPrice;
  const totalNetGainForLoad = netGainVsHomePerQtl * loadQuintals;

  return {
    homeMandi: homeMandi,
    bestMandi: bestMandi,
    isHomeMandiOptimal: bestMandi.id === homeMandi.id,
    netGainVsHomePerQtl: netGainVsHomePerQtl,
    totalNetGainForLoad: totalNetGainForLoad,
    loadQuintals: loadQuintals,
    vehicleUsed: vehicle,
    allMandis: results.slice(0, 7) // Top 7 nearby comparison markets
  };
}

module.exports = {
  getNearbyMandis,
  VEHICLES
};
