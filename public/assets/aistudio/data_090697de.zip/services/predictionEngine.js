// Time-Series Mandi Price Generation & Machine-Learning Predictive Forecasting Engine
// Simulates realistic Agmarknet price dynamics with seasonal arrival dips, festival spikes, and stochastic volatility

const CROPS = require('../data/crops');

function findCrop(cropId) {
  return CROPS.find(c => c.id === cropId) || CROPS[0];
}

/**
 * Deterministic pseudo-random generator seeded by string
 * Ensures consistent, reproducible chart curves for specific crop-mandi combinations
 */
function seededRandom(seedStr) {
  let h = 0xdeadbeef;
  for (let i = 0; i < seedStr.length; i++) {
    h = Math.imul(h ^ seedStr.charCodeAt(i), 2654435761);
  }
  return function() {
    h = Math.imul(h ^ (h >>> 16), 2246822507);
    h ^= Math.imul(h ^ (h >>> 13), 3266489909);
    return ((h >>> 0) / 4294967296);
  };
}

/**
 * Calculates seasonal price multiplier for a crop in a given month (1 to 12)
 * Harvest months see downward pressure (high arrivals); lean months see upward pressure
 */
function getSeasonalMultiplier(crop, month) {
  const isHarvest = crop.harvestMonths.includes(month);
  const isLean = crop.leanMonths.includes(month);

  if (isHarvest) {
    // Dip of 8% to 22% depending on volatility
    return 1 - (crop.volatility * 0.7);
  } else if (isLean) {
    // Peak of 10% to 30%
    return 1 + (crop.volatility * 0.85);
  } else {
    // Gradual transition
    return 1.0;
  }
}

/**
 * Generates historical daily/weekly prices (180 days past) and predictive forecast (90 days future)
 */
function generatePriceHistoryAndForecast(cropId, mandiId, baseReferenceDate = new Date()) {
  const crop = findCrop(cropId);
  const seedKey = `${cropId}_${mandiId}`;
  const rng = seededRandom(seedKey);

  // Mandi price variance offset (-5% to +6% based on mandi prominence)
  const mandiOffsetMultiplier = 0.96 + (rng() * 0.10);
  const effectiveBasePrice = Math.round(crop.baseModalPrice * mandiOffsetMultiplier);

  const historyDays = 180;
  const forecastDays = 90;
  const totalDays = historyDays + forecastDays;

  const historyPoints = [];
  const forecastPoints = [];

  let currentPrice = effectiveBasePrice * 0.94; // starting 180 days ago
  let runningSum = 0;
  const priceWindow = [];

  // Generate 180 days past
  for (let i = historyDays; i >= 0; i--) {
    const d = new Date(baseReferenceDate);
    d.setDate(d.getDate() - i);
    const month = d.getMonth() + 1;

    const seasonal = getSeasonalMultiplier(crop, month);
    // Micro noise: +/- 1.8% daily wiggle
    const dailyNoise = 1 + ((rng() - 0.49) * crop.volatility * 0.25);
    
    // Mean reversion towards target seasonal price
    const targetPrice = effectiveBasePrice * seasonal;
    currentPrice = (currentPrice * 0.88) + (targetPrice * 0.12) * dailyNoise;

    const modal = Math.round(currentPrice);
    const spread = Math.round(modal * (0.04 + rng() * 0.05));
    const min = modal - spread;
    const max = modal + Math.round(spread * 1.2);
    const arrivalsTonnes = Math.round(50 + (rng() * 350 * (crop.harvestMonths.includes(month) ? 2.5 : 0.8)));

    priceWindow.push(modal);
    if (priceWindow.length > 30) priceWindow.shift();
    const ma30 = Math.round(priceWindow.reduce((a, b) => a + b, 0) / priceWindow.length);

    historyPoints.push({
      date: d.toISOString().split('T')[0],
      displayDate: d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }),
      modalPrice: modal,
      minPrice: min,
      maxPrice: max,
      ma30: ma30,
      arrivalsTonnes: arrivalsTonnes,
      type: "historical"
    });
  }

  // Today's anchor price
  const todayPoint = historyPoints[historyPoints.length - 1];
  const currentModal = todayPoint.modalPrice;
  const previousModal = historyPoints[historyPoints.length - 2]?.modalPrice || currentModal;
  const dayChangeRs = currentModal - previousModal;
  const dayChangePercent = Number(((dayChangeRs / previousModal) * 100).toFixed(2));

  // Predictive forecasting model for upcoming 90 days
  let forecastPrice = currentModal;
  for (let f = 1; f <= forecastDays; f++) {
    const fd = new Date(baseReferenceDate);
    fd.setDate(fd.getDate() + f);
    const month = fd.getMonth() + 1;

    const seasonal = getSeasonalMultiplier(crop, month);
    const targetPrice = effectiveBasePrice * seasonal;

    // Gradual drift towards seasonal target with expanding uncertainty cone
    const driftStep = 0.035;
    forecastPrice = (forecastPrice * (1 - driftStep)) + (targetPrice * driftStep);

    // Confidence interval expands with time horizon (sqrt of days ahead)
    const confidenceWidth = Math.round(forecastPrice * (crop.volatility * 0.18 * Math.sqrt(f)));
    const predictedModal = Math.round(forecastPrice);

    forecastPoints.push({
      date: fd.toISOString().split('T')[0],
      displayDate: fd.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }),
      daysAhead: f,
      modalPrice: predictedModal,
      upperBound: predictedModal + confidenceWidth,
      lowerBound: Math.max(crop.msp2025 > 0 ? Math.round(crop.msp2025 * 0.95) : 500, predictedModal - confidenceWidth),
      type: "forecast"
    });
  }

  // Forecast summaries at key milestones (+15, +30, +60, +90 days)
  const milestone15 = forecastPoints[14] || forecastPoints[forecastPoints.length - 1];
  const milestone30 = forecastPoints[29] || forecastPoints[forecastPoints.length - 1];
  const milestone60 = forecastPoints[59] || forecastPoints[forecastPoints.length - 1];
  const milestone90 = forecastPoints[89] || forecastPoints[forecastPoints.length - 1];

  const change30Days = milestone30.modalPrice - currentModal;
  const change30DaysPercent = Number(((change30Days / currentModal) * 100).toFixed(1));

  let trajectory = "STABLE";
  if (change30DaysPercent >= 3.5) trajectory = "BULLISH (UPWARD)";
  else if (change30DaysPercent <= -3.5) trajectory = "BEARISH (DOWNWARD)";

  // MSP comparison
  const msp = crop.msp2025 || crop.msp2024 || 0;
  let mspStatus = "NO_MSP";
  let mspDifference = 0;
  let mspDifferencePercent = 0;
  if (msp > 0) {
    mspDifference = currentModal - msp;
    mspDifferencePercent = Number(((mspDifference / msp) * 100).toFixed(1));
    if (mspDifference >= 0) {
      mspStatus = "ABOVE_MSP";
    } else {
      mspStatus = "BELOW_MSP";
    }
  }

  return {
    crop: {
      id: crop.id,
      name: crop.name,
      nameHi: crop.nameHi,
      category: crop.category,
      categoryHi: crop.categoryHi,
      msp: msp,
      volatility: crop.volatility
    },
    currentPrices: {
      modalPrice: currentModal,
      minPrice: todayPoint.minPrice,
      maxPrice: todayPoint.maxPrice,
      dayChangeRs: dayChangeRs,
      dayChangePercent: dayChangePercent,
      arrivalsTonnes: todayPoint.arrivalsTonnes,
      asOfDate: todayPoint.date,
      mspStatus: mspStatus,
      mspDifference: mspDifference,
      mspDifferencePercent: mspDifferencePercent
    },
    forecastSummary: {
      trajectory: trajectory,
      change30DaysRs: change30Days,
      change30DaysPercent: change30DaysPercent,
      milestones: {
        day15: milestone15,
        day30: milestone30,
        day60: milestone60,
        day90: milestone90
      }
    },
    historyPoints: historyPoints.slice(-60), // Last 60 days for fast responsive UI
    fullHistoryCount: historyPoints.length,
    forecastPoints: forecastPoints
  };
}

module.exports = {
  generatePriceHistoryAndForecast,
  findCrop
};
