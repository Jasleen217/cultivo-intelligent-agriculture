@echo off
echo ========================================================
echo   KRISHI MANDI PRICE PREDICTION & CROP PLATFORM
echo ========================================================
echo.
echo Starting local web server on http://localhost:3000 ...
echo Press Ctrl+C in this window to stop the server.
echo.
node server.js
pause
