// High-Performance Interactive SVG Mandi Price & Forecast Chart Engine
// Fully responsive, handles historical time-series, moving averages, and probabilistic prediction cones

class MandiChart {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    this.historyData = [];
    this.forecastData = [];
    this.cropName = "";
    this.init();
  }

  init() {
    if (!this.container) return;
    window.addEventListener('resize', () => {
      if (this.historyData.length > 0) {
        this.render(this.historyData, this.forecastData, this.cropName);
      }
    });
  }

  render(historyPoints, forecastPoints, cropName = "") {
    this.historyData = historyPoints || [];
    this.forecastData = forecastPoints || [];
    this.cropName = cropName;

    if (!this.container) return;
    this.container.innerHTML = "";

    const width = this.container.clientWidth || 800;
    const height = this.container.clientHeight || 360;

    const padLeft = 65;
    const padRight = 35;
    const padTop = 25;
    const padBottom = 45;

    const plotWidth = width - padLeft - padRight;
    const plotHeight = height - padTop - padBottom;

    const combinedPoints = [
      ...this.historyData.map(p => ({ ...p, isForecast: false })),
      ...this.forecastData.map(p => ({ ...p, isForecast: true }))
    ];

    if (combinedPoints.length === 0) {
      this.container.innerHTML = `<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#64748b;">No chart data available</div>`;
      return;
    }

    // Determine Y-axis min and max
    let minPrice = Infinity;
    let maxPrice = -Infinity;

    combinedPoints.forEach(p => {
      const val = p.modalPrice;
      const low = p.lowerBound !== undefined ? p.lowerBound : val;
      const high = p.upperBound !== undefined ? p.upperBound : val;
      if (low < minPrice) minPrice = low;
      if (high > maxPrice) maxPrice = high;
    });

    // Add 8% buffer
    const priceRange = maxPrice - minPrice;
    const yMin = Math.max(0, Math.floor((minPrice - priceRange * 0.08) / 100) * 100);
    const yMax = Math.ceil((maxPrice + priceRange * 0.08) / 100) * 100;
    const effectiveRange = (yMax - yMin) || 1;

    const getX = (index) => padLeft + (index / (combinedPoints.length - 1)) * plotWidth;
    const getY = (price) => padTop + plotHeight - ((price - yMin) / effectiveRange) * plotHeight;

    const todayIndex = this.historyData.length - 1;
    const todayX = getX(todayIndex);

    // SVG elements
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
    svg.setAttribute("width", "100%");
    svg.setAttribute("height", "100%");

    // Defs for gradients
    const defs = document.createElementNS("http://www.w3.org/2000/svg", "defs");
    defs.innerHTML = `
      <linearGradient id="historyGradient" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#059669" stop-opacity="0.28"/>
        <stop offset="100%" stop-color="#059669" stop-opacity="0.0"/>
      </linearGradient>
      <linearGradient id="forecastConeGradient" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#3b82f6" stop-opacity="0.22"/>
        <stop offset="100%" stop-color="#3b82f6" stop-opacity="0.05"/>
      </linearGradient>
      <filter id="shadowFilter" x="-10%" y="-10%" width="120%" height="120%">
        <feDropShadow dx="0" dy="2" stdDeviation="3" flood-opacity="0.15" />
      </filter>
    `;
    svg.appendChild(defs);

    // Background Gridlines (5 horizontal tiers)
    const gridGroup = document.createElementNS("http://www.w3.org/2000/svg", "g");
    const gridTiers = 5;
    for (let i = 0; i <= gridTiers; i++) {
      const priceVal = Math.round(yMin + (effectiveRange * (i / gridTiers)));
      const yPos = getY(priceVal);

      // Line
      const gridLine = document.createElementNS("http://www.w3.org/2000/svg", "line");
      gridLine.setAttribute("x1", padLeft);
      gridLine.setAttribute("y1", yPos);
      gridLine.setAttribute("x2", width - padRight);
      gridLine.setAttribute("y2", yPos);
      gridLine.setAttribute("stroke", "#e2e8f0");
      gridLine.setAttribute("stroke-width", "1");
      gridLine.setAttribute("stroke-dasharray", i === 0 ? "none" : "3,3");
      gridGroup.appendChild(gridLine);

      // Label
      const label = document.createElementNS("http://www.w3.org/2000/svg", "text");
      label.setAttribute("x", padLeft - 10);
      label.setAttribute("y", yPos + 4);
      label.setAttribute("text-anchor", "end");
      label.setAttribute("fill", "#64748b");
      label.setAttribute("font-size", "11px");
      label.setAttribute("font-weight", "600");
      label.textContent = `₹${priceVal.toLocaleString('en-IN')}`;
      gridGroup.appendChild(label);
    }
    svg.appendChild(gridGroup);

    // Confidence Interval Area for Forecast
    if (this.forecastData.length > 0) {
      let upperPath = `M ${todayX} ${getY(combinedPoints[todayIndex].modalPrice)}`;
      let lowerPath = "";

      for (let i = 0; i < this.forecastData.length; i++) {
        const point = this.forecastData[i];
        const idx = todayIndex + 1 + i;
        const x = getX(idx);
        const yUpper = getY(point.upperBound);
        upperPath += ` L ${x} ${yUpper}`;
      }

      for (let i = this.forecastData.length - 1; i >= 0; i--) {
        const point = this.forecastData[i];
        const idx = todayIndex + 1 + i;
        const x = getX(idx);
        const yLower = getY(point.lowerBound);
        lowerPath += ` L ${x} ${yLower}`;
      }
      lowerPath += ` L ${todayX} ${getY(combinedPoints[todayIndex].modalPrice)} Z`;

      const conePathElem = document.createElementNS("http://www.w3.org/2000/svg", "path");
      conePathElem.setAttribute("d", upperPath + lowerPath);
      conePathElem.setAttribute("fill", "url(#forecastConeGradient)");
      conePathElem.setAttribute("stroke", "#93c5fd");
      conePathElem.setAttribute("stroke-width", "1");
      conePathElem.setAttribute("stroke-dasharray", "4,4");
      svg.appendChild(conePathElem);
    }

    // Historical Price Area Fill
    if (this.historyData.length > 0) {
      let histAreaPath = `M ${getX(0)} ${getY(this.historyData[0].modalPrice)}`;
      for (let i = 1; i < this.historyData.length; i++) {
        histAreaPath += ` L ${getX(i)} ${getY(this.historyData[i].modalPrice)}`;
      }
      histAreaPath += ` L ${todayX} ${padTop + plotHeight} L ${getX(0)} ${padTop + plotHeight} Z`;

      const areaElem = document.createElementNS("http://www.w3.org/2000/svg", "path");
      areaElem.setAttribute("d", histAreaPath);
      areaElem.setAttribute("fill", "url(#historyGradient)");
      svg.appendChild(areaElem);

      // 30-Day Moving Average Line (Dotted Amber)
      let maPath = "";
      let started = false;
      for (let i = 0; i < this.historyData.length; i++) {
        if (this.historyData[i].ma30) {
          const x = getX(i);
          const y = getY(this.historyData[i].ma30);
          if (!started) {
            maPath += `M ${x} ${y}`;
            started = true;
          } else {
            maPath += ` L ${x} ${y}`;
          }
        }
      }
      if (maPath) {
        const maElem = document.createElementNS("http://www.w3.org/2000/svg", "path");
        maElem.setAttribute("d", maPath);
        maElem.setAttribute("fill", "none");
        maElem.setAttribute("stroke", "#f59e0b");
        maElem.setAttribute("stroke-width", "2");
        maElem.setAttribute("stroke-dasharray", "4,3");
        svg.appendChild(maElem);
      }

      // Historical Price Line (Emerald Solid)
      let histLinePath = `M ${getX(0)} ${getY(this.historyData[0].modalPrice)}`;
      for (let i = 1; i < this.historyData.length; i++) {
        histLinePath += ` L ${getX(i)} ${getY(this.historyData[i].modalPrice)}`;
      }
      const histLineElem = document.createElementNS("http://www.w3.org/2000/svg", "path");
      histLineElem.setAttribute("d", histLinePath);
      histLineElem.setAttribute("fill", "none");
      histLineElem.setAttribute("stroke", "#059669");
      histLineElem.setAttribute("stroke-width", "3");
      histLineElem.setAttribute("stroke-linecap", "round");
      svg.appendChild(histLineElem);
    }

    // Forecast Price Line (Royal Blue Dashed)
    if (this.forecastData.length > 0) {
      let foreLinePath = `M ${todayX} ${getY(combinedPoints[todayIndex].modalPrice)}`;
      for (let i = 0; i < this.forecastData.length; i++) {
        const idx = todayIndex + 1 + i;
        foreLinePath += ` L ${getX(idx)} ${getY(this.forecastData[i].modalPrice)}`;
      }
      const foreLineElem = document.createElementNS("http://www.w3.org/2000/svg", "path");
      foreLineElem.setAttribute("d", foreLinePath);
      foreLineElem.setAttribute("fill", "none");
      foreLineElem.setAttribute("stroke", "#2563eb");
      foreLineElem.setAttribute("stroke-width", "2.8");
      foreLineElem.setAttribute("stroke-dasharray", "6,4");
      foreLineElem.setAttribute("stroke-linecap", "round");
      svg.appendChild(foreLineElem);
    }

    // Vertical "Today" Separator Line
    const todayLine = document.createElementNS("http://www.w3.org/2000/svg", "line");
    todayLine.setAttribute("x1", todayX);
    todayLine.setAttribute("y1", padTop);
    todayLine.setAttribute("x2", todayX);
    todayLine.setAttribute("y2", padTop + plotHeight);
    todayLine.setAttribute("stroke", "#dc2626");
    todayLine.setAttribute("stroke-width", "1.8");
    todayLine.setAttribute("stroke-dasharray", "4,4");
    svg.appendChild(todayLine);

    // "Today / आज" Badge
    const todayBadge = document.createElementNS("http://www.w3.org/2000/svg", "text");
    todayBadge.setAttribute("x", todayX);
    todayBadge.setAttribute("y", padTop - 8);
    todayBadge.setAttribute("text-anchor", "middle");
    todayBadge.setAttribute("fill", "#dc2626");
    todayBadge.setAttribute("font-size", "11px");
    todayBadge.setAttribute("font-weight", "800");
    todayBadge.textContent = "TODAY (आज)";
    svg.appendChild(todayBadge);

    // X-Axis Date Ticks (approx 6 ticks across timeline)
    const tickCount = 6;
    for (let k = 0; k < tickCount; k++) {
      const idx = Math.round(k * ((combinedPoints.length - 1) / (tickCount - 1)));
      const point = combinedPoints[idx];
      const xPos = getX(idx);

      const tickLabel = document.createElementNS("http://www.w3.org/2000/svg", "text");
      tickLabel.setAttribute("x", xPos);
      tickLabel.setAttribute("y", padTop + plotHeight + 20);
      tickLabel.setAttribute("text-anchor", "middle");
      tickLabel.setAttribute("fill", "#64748b");
      tickLabel.setAttribute("font-size", "11px");
      tickLabel.setAttribute("font-weight", "600");
      tickLabel.textContent = point.displayDate || point.date;
      svg.appendChild(tickLabel);
    }

    // Interactive Crosshair & Tooltip Overlay
    const crosshair = document.createElementNS("http://www.w3.org/2000/svg", "line");
    crosshair.setAttribute("y1", padTop);
    crosshair.setAttribute("y2", padTop + plotHeight);
    crosshair.setAttribute("stroke", "#0f172a");
    crosshair.setAttribute("stroke-width", "1");
    crosshair.setAttribute("stroke-dasharray", "3,3");
    crosshair.style.display = "none";
    svg.appendChild(crosshair);

    const hoverDot = document.createElementNS("http://www.w3.org/2000/svg", "circle");
    hoverDot.setAttribute("r", "5");
    hoverDot.setAttribute("fill", "#059669");
    hoverDot.setAttribute("stroke", "#ffffff");
    hoverDot.setAttribute("stroke-width", "2");
    hoverDot.style.display = "none";
    svg.appendChild(hoverDot);

    // Tooltip HTML container
    let tooltip = this.container.querySelector('.chart-tooltip');
    if (!tooltip) {
      tooltip = document.createElement('div');
      tooltip.className = 'chart-tooltip';
      tooltip.style.cssText = `
        position: absolute;
        pointer-events: none;
        background: rgba(15, 23, 42, 0.92);
        color: white;
        padding: 8px 12px;
        border-radius: 8px;
        font-size: 12px;
        line-height: 1.4;
        display: none;
        z-index: 10;
        box-shadow: 0 4px 12px rgba(0,0,0,0.25);
        white-space: nowrap;
        backdrop-filter: blur(4px);
        border: 1px solid rgba(255,255,255,0.15);
      `;
      this.container.appendChild(tooltip);
    }

    // Mousemove handler for smooth hover inspection
    svg.addEventListener('mousemove', (e) => {
      const rect = svg.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      
      if (mouseX < padLeft || mouseX > width - padRight) {
        crosshair.style.display = "none";
        hoverDot.style.display = "none";
        tooltip.style.display = "none";
        return;
      }

      const ratio = (mouseX - padLeft) / plotWidth;
      const pointIndex = Math.min(combinedPoints.length - 1, Math.max(0, Math.round(ratio * (combinedPoints.length - 1))));
      const point = combinedPoints[pointIndex];
      const pX = getX(pointIndex);
      const pY = getY(point.modalPrice);

      crosshair.setAttribute("x1", pX);
      crosshair.setAttribute("x2", pX);
      crosshair.style.display = "block";

      hoverDot.setAttribute("cx", pX);
      hoverDot.setAttribute("cy", pY);
      hoverDot.setAttribute("fill", point.isForecast ? "#2563eb" : "#059669");
      hoverDot.style.display = "block";

      let tipHtml = `
        <div style="font-weight:700;margin-bottom:2px;color:${point.isForecast ? '#60a5fa' : '#34d399'};">
          ${point.isForecast ? '🔮 AI Forecast' : '📊 Mandi Rate'} - ${point.displayDate || point.date}
        </div>
        <div>Modal Price: <strong>₹${point.modalPrice.toLocaleString('en-IN')}/Qtl</strong></div>
      `;

      if (point.isForecast) {
        tipHtml += `
          <div style="font-size:11px;color:#cbd5e1;">Confidence: ₹${point.lowerBound.toLocaleString('en-IN')} - ₹${point.upperBound.toLocaleString('en-IN')}</div>
          <div style="font-size:10px;color:#93c5fd;">Horizon: +${point.daysAhead} days</div>
        `;
      } else {
        if (point.minPrice && point.maxPrice) {
          tipHtml += `<div style="font-size:11px;color:#cbd5e1;">Range: ₹${point.minPrice} - ₹${point.maxPrice}</div>`;
        }
        if (point.arrivalsTonnes) {
          tipHtml += `<div style="font-size:10px;color:#a7f3d0;">Arrivals: ${point.arrivalsTonnes} Tonnes</div>`;
        }
      }

      tooltip.innerHTML = tipHtml;
      tooltip.style.display = "block";

      // Positioning tooltip
      const tipWidth = tooltip.offsetWidth;
      let tipLeft = pX - tipWidth / 2;
      if (tipLeft < 10) tipLeft = 10;
      if (tipLeft + tipWidth > width - 10) tipLeft = width - tipWidth - 10;
      tooltip.style.left = `${tipLeft}px`;
      tooltip.style.top = `${Math.max(10, pY - 70)}px`;
    });

    svg.addEventListener('mouseleave', () => {
      crosshair.style.display = "none";
      hoverDot.style.display = "none";
      tooltip.style.display = "none";
    });

    this.container.appendChild(svg);
  }
}

if (typeof window !== 'undefined') {
  window.MandiChart = MandiChart;
}
