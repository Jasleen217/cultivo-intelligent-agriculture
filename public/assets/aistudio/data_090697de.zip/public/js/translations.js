// Dual-Language Dictionary: English and Hindi (हिंदी)
// Translates all UI widgets, input fields, tabs, metric cards, and advisories

const TRANSLATIONS = {
  en: {
    appTitle: "Krishi Mandi AI",
    appSubtitle: "Mandi Price Prediction, Market Arbitrage & Smart Crop Recommendation Platform",
    tickerLive: "LIVE MANDI RATES",
    printReport: "Download / Print Advisory",
    toggleLanguage: "हिंदी में बदलें (Hindi)",
    
    // Form Inputs
    farmerProfileTitle: "Enter Farm & Location Details",
    stateLabel: "State",
    districtLabel: "District",
    mandiLabel: "Primary Mandi / APMC",
    cropLabel: "Select Crop",
    soilLabel: "Soil Type",
    seasonLabel: "Agricultural Season",
    landSizeLabel: "Farm Size (Acres)",
    irrigationLabel: "Irrigation Facility",
    budgetLabel: "Investment Capacity",
    analyzeBtn: "Analyze Market Rates & Generate AI Insights",
    loadingText: "Fetching Agmarknet rates and running AI prediction...",

    // Tabs
    tabPrices: "Mandi Rates & 90-Day Forecast",
    tabAdvisory: "AI Selling-Period Advisor",
    tabArbitrage: "Nearby Mandis & Transport Arbitrage",
    tabCropRecommend: "Crop Suggestion & Farm ROI",

    // Metrics
    metricCurrentModal: "Current Modal Price",
    metricMinMax: "Daily Min - Max Range",
    metricDayChange: "Daily Price Shift",
    metricArrivals: "Today's Mandi Arrivals",
    metricMsp: "Govt MSP Comparison",
    quintalUnit: "₹ / Quintal",
    tonnesUnit: "Tonnes",

    // Forecast Chart
    chartTitle: "Mandi Price Trend & 90-Day AI Forecast Horizon",
    chartSubtitle: "Historical daily modal prices with moving average and 85% predictive confidence intervals",
    legendHistorical: "Past 60-Day Mandi Price",
    legendMA: "30-Day Moving Average",
    legendForecast: "AI Predicted Price",
    legendConfidence: "85% Confidence Range",

    // Forecast Milestones
    milestone15: "In 15 Days (+15D)",
    milestone30: "In 30 Days (+1M)",
    milestone60: "In 60 Days (+2M)",
    milestone90: "In 90 Days (+3M)",

    // Selling Advisor (Tab 2)
    voiceBtnListen: "Listen Audio Advisory (Kisan Vaani)",
    voiceBtnStop: "Stop Audio",
    holdingSliderLabel: "Holding Duration Simulator:",
    daysSuffix: "Days",
    storageOptionLabel: "Storage Type:",
    storageWarehouse: "Certified Warehouse (₹20-25/qtl/mo)",
    storageCold: "Cold Storage (₹45-55/qtl/mo)",
    storageOnFarm: "On-Farm Traditional Kothar (Low cost, higher rot risk)",

    tableColItem: "Cost Factor / Revenue",
    tableColRate: "Amount per Quintal",
    tableColNotes: "Economic Detail",
    currMandiPrice: "Today's Mandi Spot Price",
    predMandiPrice: "Projected Price at Harvest Exit",
    grossDelta: "Gross Price Difference",
    warehouseCharge: "Storage & Bagging Charges",
    spoilageDeduction: "Natural Moisture Loss & Shrinkage",
    interestCost: "Cost of Capital (7% p.a. KCC interest)",
    netProfitGain: "Net Farmer Profit / (Loss) from Holding",

    // Arbitrage (Tab 3)
    vehicleLabel: "Transport Vehicle:",
    loadLabel: "Produce Load Size:",
    arbitrageHeader: "Nearby Mandis Realized Price Comparison",
    arbitrageWinnerTitle: "Optimal Market Winner Identified!",
    arbitrageWinnerSub: "Taking your produce to this mandi yields maximum net pocket income even after fuel and handling costs.",
    colMandi: "Mandi / APMC",
    colDistance: "Distance",
    colModalRate: "Modal Rate",
    colTransportCost: "Freight Cost",
    colApmcCost: "Mandi Fee & Unloading",
    colNetRealized: "Net Pocket Return",

    // Crop Recommendation (Tab 4)
    cropSuitability: "Suitability Match",
    cropYieldAcre: "Expected Yield",
    cropCostAcre: "Cultivation Cost / Acre",
    cropTotalNetProfit: "Projected Total Net Farm Profit",
    cropRoi: "Expected Return on Investment (ROI)",
    cropSowingWindow: "Sowing Window:",
    cropFertilizer: "Fertilizer Formula (NPK):",

    // Simulator
    simTitle: "What-If Farm Income Simulator",
    simAcreage: "Total Acreage:",
    simExpectedRate: "Expected Sale Price (₹/Qtl):",
    simGrossRev: "Gross Projected Sales:",
    simTotalCost: "Total Input Costs:",
    simNetIncome: "Net Farm Take-Home:",

    // Report
    reportTitle: "Krishi Mandi Advisory & Profitability Certificate",
    reportDate: "Date Generated:",
    closeBtn: "Close"
  },

  hi: {
    appTitle: "कृषि मंडी एआई",
    appSubtitle: "मंडी भाव भविष्यवाणी, बाजार मुनाफा तुलना एवं स्मार्ट फसल सुझाव मंच",
    tickerLive: "लाइव मंडी भाव",
    printReport: "परामर्श रिपोर्ट डाउनलोड / प्रिंट करें",
    toggleLanguage: "Switch to English",
    
    // Form Inputs
    farmerProfileTitle: "खेत व स्थान की जानकारी दर्ज करें",
    stateLabel: "राज्य",
    districtLabel: "जिला",
    mandiLabel: "मुख्य मंडी / APMC",
    cropLabel: "फसल चुनें",
    soilLabel: "मिट्टी का प्रकार",
    seasonLabel: "कृषि मौसम (सीजन)",
    landSizeLabel: "खेत का क्षेत्रफल (एकड़)",
    irrigationLabel: "सिंचाई सुविधा",
    budgetLabel: "लागत / बजट क्षमता",
    analyzeBtn: "मंडी भाव विश्लेषण एवं एआई सलाह प्राप्त करें",
    loadingText: "एगमार्कनेट भाव लोड हो रहे हैं और एआई मॉडल गणना कर रहा है...",

    // Tabs
    tabPrices: "मंडी भाव व 90-दिवसीय अनुमान",
    tabAdvisory: "कब बेचें - एआई विक्रय सलाहकार",
    tabArbitrage: "नजदीकी मंडियां व परिवहन मुनाफा",
    tabCropRecommend: "उपयुक्त फसल सुझाव व लाभ",

    // Metrics
    metricCurrentModal: "आज का मॉडल (औसत) भाव",
    metricMinMax: "दैनिक न्यूनतम - अधिकतम भाव",
    metricDayChange: "दैनिक भाव में बदलाव",
    metricArrivals: "आज की कुल आवक",
    metricMsp: "सरकारी MSP से तुलना",
    quintalUnit: "₹ / क्विंटल",
    tonnesUnit: "टन",

    // Forecast Chart
    chartTitle: "मंडी भाव रुझान एवं आगामी 90 दिनों का एआई पूर्वानुमान",
    chartSubtitle: "पिछले 60 दिनों के दैनिक भाव, मूविंग एवरेज और 85% संभाव्यता बैंड",
    legendHistorical: "पिछले 60 दिनों का भाव",
    legendMA: "30-दिवसीय मूविंग एवरेज",
    legendForecast: "एआई अनुमानित भाव",
    legendConfidence: "85% विश्वसनीयता दायरा",

    // Forecast Milestones
    milestone15: "15 दिनों में (+15 दिन)",
    milestone30: "30 दिनों में (+1 माह)",
    milestone60: "60 दिनों में (+2 माह)",
    milestone90: "90 दिनों में (+3 माह)",

    // Selling Advisor (Tab 2)
    voiceBtnListen: "किसान वाणी सुनें (ऑडियो सलाह)",
    voiceBtnStop: "ऑडियो बंद करें",
    holdingSliderLabel: "भंडारण अवधि सिम्युलेटर:",
    daysSuffix: "दिन",
    storageOptionLabel: "भंडारण का माध्यम:",
    storageWarehouse: "प्रमाणित वेयरहाउस (₹20-25/क्विंटल/माह)",
    storageCold: "कोल्ड स्टोरेज (₹45-55/क्विंटल/माह)",
    storageOnFarm: "घर का पारम्परिक कोठार (कम खर्च, सड़न का अधिक खतरा)",

    tableColItem: "लागत घटक / आमदनी",
    tableColRate: "प्रति क्विंटल राशि",
    tableColNotes: "आर्थिक विवरण",
    currMandiPrice: "आज का हाजिर मंडी भाव",
    predMandiPrice: "भविष्य का अनुमानित भाव",
    grossDelta: "सकल मूल्य अंतर",
    warehouseCharge: "गोदाम किराया व बोरी खर्च",
    spoilageDeduction: "नमी सूख व प्राकृतिक वजन ह्रास",
    interestCost: "पूंजी की लागत (7% KCC ऋण ब्याज)",
    netProfitGain: "रोक कर रखने पर शुद्ध अतिरिक्त लाभ / (हानि)",

    // Arbitrage (Tab 3)
    vehicleLabel: "परिवहन साधन:",
    loadLabel: "फसल मात्रा (क्विंटल):",
    arbitrageHeader: "नजदीकी मंडियों में शुद्ध जेब भाव की तुलना",
    arbitrageWinnerTitle: "सर्वोत्तम मंडी चुनी गई!",
    arbitrageWinnerSub: "इस मंडी में फसल ले जाने से डीजल व भाड़ा निकालने के बाद भी किसान को सर्वाधिक शुद्ध लाभ मिलेगा।",
    colMandi: "मंडी / APMC",
    colDistance: "दूरी",
    colModalRate: "मॉडल भाव",
    colTransportCost: "मालभाड़ा",
    colApmcCost: "मंडी शुल्क व पल्लेदारी",
    colNetRealized: "शुद्ध जेब में आने वाला भाव",

    // Crop Recommendation (Tab 4)
    cropSuitability: "अनुकूलता स्कोर",
    cropYieldAcre: "अनुमानित पैदावार",
    cropCostAcre: "प्रति एकड़ खेती लागत",
    cropTotalNetProfit: "कुल खेत का शुद्ध अनुमानित मुनाफा",
    cropRoi: "निवेश पर लाभ दर (ROI)",
    cropSowingWindow: "बुवाई का समय:",
    cropFertilizer: "खाद व उर्वरक अनुपात (NPK):",

    // Simulator
    simTitle: "खेत आय सिम्युलेटर (What-If)",
    simAcreage: "कुल रकबा (एकड़):",
    simExpectedRate: "अपेक्षित बिक्री भाव (₹/क्विंटल):",
    simGrossRev: "सकल अनुमानित बिक्री:",
    simTotalCost: "कुल लागत:",
    simNetIncome: "शुद्ध किसान बचत:",

    // Report
    reportTitle: "कृषि मंडी परामर्श एवं लाभप्रदता प्रमाण पत्र",
    reportDate: "जारी दिनांक:",
    closeBtn: "बंद करें"
  }
};

if (typeof window !== 'undefined') {
  window.TRANSLATIONS = TRANSLATIONS;
}
