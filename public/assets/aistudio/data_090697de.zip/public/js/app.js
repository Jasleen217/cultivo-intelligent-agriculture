/**
 * AgriGreen - Simple Client JavaScript
 * Matching the AgriGreen UI Reference (Images 1, 2, 3)
 */

let allStates = [];

// Initialize when page loads
window.onload = async function () {
  const isAuth = await checkAuthentication();
  if (!isAuth) return;

  loadDropdowns();

  // Update district dropdown when state changes
  document.getElementById('input-state').addEventListener('change', updateDistricts);

  // Analyze button click
  document.getElementById('btn-analyze').addEventListener('click', analyzeData);

  // Logout button click
  const logoutBtn = document.getElementById('btn-logout');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', async () => {
      try {
        await fetch('/api/auth/logout', { method: 'POST' });
      } catch (e) {}
      window.location.href = '/login.html';
    });
  }
};

// 0. Verify Farmer Authentication
async function checkAuthentication() {
  try {
    const res = await fetch('/api/auth/me');
    const data = await res.json();
    if (!data.authenticated) {
      window.location.href = '/login.html';
      return false;
    }
    const nameDisplay = document.getElementById('farmer-name-display');
    if (nameDisplay && data.user) {
      nameDisplay.textContent = data.user.fullName || 'Farmer';
    }
    return true;
  } catch (err) {
    window.location.href = '/login.html';
    return false;
  }
}

// 1. Fetch States and Crops to Populate Dropdowns
async function loadDropdowns() {
  try {
    const res = await fetch('/api/metadata');
    const data = await res.json();
    allStates = data.states;

    // Fill State dropdown
    const stateSelect = document.getElementById('input-state');
    stateSelect.innerHTML = data.states.map(s => `<option value="${s.id}">${s.name}</option>`).join('');

    // Fill Crop dropdown
    const cropSelect = document.getElementById('input-crop');
    cropSelect.innerHTML = data.crops.map(c => `<option value="${c.id}">${c.name}</option>`).join('');

    // Initialize districts
    updateDistricts();

    // Run initial analysis automatically on load
    analyzeData();
  } catch (err) {
    console.error("Error loading dropdowns:", err);
  }
}

// 2. Update Districts Dropdown Based on Selected State
function updateDistricts() {
  const selectedStateId = document.getElementById('input-state').value;
  const stateObj = allStates.find(s => s.id === selectedStateId) || allStates[0];
  const districtSelect = document.getElementById('input-district');

  if (stateObj && stateObj.districts) {
    districtSelect.innerHTML = stateObj.districts.map(d => `<option value="${d.id}">${d.name}</option>`).join('');
  }
}

// 3. Main Function: Analyze Farm & Mandi Data
async function analyzeData() {
  const btn = document.getElementById('btn-analyze');
  btn.disabled = true;
  btn.textContent = "Analyzing...";

  // Read input values
  const soilType = document.getElementById('input-soil').value;
  const temperature = document.getElementById('input-temp').value;
  const weather = document.getElementById('input-weather').value;
  const stateId = document.getElementById('input-state').value;
  const districtId = document.getElementById('input-district').value;
  const cropId = document.getElementById('input-crop').value;
  const landArea = parseFloat(document.getElementById('input-land-size').value) || 5;

  try {
    // A. Fetch Price Forecast
    const forecastRes = await fetch('/api/mandi/forecast', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ cropId: cropId })
    });
    const forecastData = await forecastRes.json();

    // B. Fetch Nearby Mandi Rates
    const nearbyRes = await fetch('/api/mandi/nearby', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ stateId: stateId, districtId: districtId, cropId: cropId })
    });
    const nearbyData = await nearbyRes.json();

    // C. Fetch Crop Suggestions
    const cropRes = await fetch('/api/crop/recommend', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ stateId: stateId, soilType: soilType, landSizeAcres: landArea })
    });
    const cropData = await cropRes.json();

    // D. Fetch Selling Advice
    const advRes = await fetch('/api/insights/selling-period', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ cropId: cropId, holdingTargetDays: 30 })
    });
    const advisoryData = await advRes.json();

    // 1. Recommended Crops (Exact style of Image 1: "Recommended Crops: Wheat, Maize, Rice")
    const topCropNames = (cropData.topCrops || []).slice(0, 3).map(c => c.name).join(', ') || 'Wheat, Maize, Rice';
    document.getElementById('disp-recommended-crops').textContent = topCropNames;

    // 2. Current Price & Forecast
    const currentPrice = forecastData.currentPrices.modalPrice;
    const futurePrice = forecastData.forecastSummary.milestones.day30.modalPrice;
    const change = futurePrice - currentPrice;
    const percent = ((change / currentPrice) * 100).toFixed(1);

    document.getElementById('disp-current-price').textContent = `₹${currentPrice.toLocaleString('en-IN')} / Quintal`;
    document.getElementById('disp-pred-price').textContent = `₹${futurePrice.toLocaleString('en-IN')} / Quintal (${change >= 0 ? '+' : ''}₹${change}, ${percent}%)`;
    document.getElementById('disp-selling-advice').textContent = advisoryData.verdict === 'HOLD'
      ? "HOLD FOR 3-4 WEEKS"
      : "SELL TODAY";

    // 3. Render Nearby Mandis Table
    displayMandiTable(nearbyData.allMandis);

    // 4. Render Simple Canvas Chart
    drawPriceChart(forecastData.historyPoints, forecastData.forecastPoints);

  } catch (err) {
    console.error("Error analyzing data:", err);
  } finally {
    btn.disabled = false;
    btn.textContent = "Analyze";
  }
}

// 4. Render Nearby Mandis in Table
function displayMandiTable(mandis) {
  const tableBody = document.getElementById('mandi-table-body');
  if (!mandis || mandis.length === 0) {
    tableBody.innerHTML = '<tr><td colspan="4">No mandi data available</td></tr>';
    return;
  }

  tableBody.innerHTML = mandis.map((m, idx) => `
    <tr class="${idx === 0 ? 'highlight-row' : ''}">
      <td>${m.name} ${idx === 0 ? '★ (Best Price)' : ''}</td>
      <td>${m.districtName || ''}</td>
      <td>${m.distanceKm} km</td>
      <td><strong>₹${m.modalPrice.toLocaleString('en-IN')}</strong></td>
    </tr>
  `).join('');
}

// 5. Draw Clean Canvas Line Chart
function drawPriceChart(history, forecast) {
  const canvas = document.getElementById('priceChart');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  const width = canvas.width;
  const height = canvas.height;
  ctx.clearRect(0, 0, width, height);

  const past = (history || []).slice(-15);
  const future = (forecast || []).slice(0, 15);
  const allPoints = [...past, ...future];

  if (allPoints.length === 0) return;

  let min = Infinity;
  let max = -Infinity;
  allPoints.forEach(p => {
    if (p.modalPrice < min) min = p.modalPrice;
    if (p.modalPrice > max) max = p.modalPrice;
  });

  const range = (max - min) || 1;
  const padX = 40;
  const padY = 20;
  const plotW = width - padX * 2;
  const plotH = height - padY * 2;

  const getX = (i) => padX + (i / (allPoints.length - 1)) * plotW;
  const getY = (val) => padY + plotH - ((val - min) / range) * plotH;

  // Gridlines
  ctx.strokeStyle = '#eef1f5';
  ctx.fillStyle = '#7f8c8d';
  ctx.font = '11px sans-serif';
  ctx.lineWidth = 1;

  for (let i = 0; i <= 2; i++) {
    const val = Math.round(min + (range * (i / 2)));
    const y = getY(val);
    ctx.beginPath();
    ctx.moveTo(padX, y);
    ctx.lineTo(width - padX, y);
    ctx.stroke();
    ctx.fillText(`₹${val}`, 5, y + 4);
  }

  // Historical Price Line (Green #27ae60)
  ctx.beginPath();
  ctx.strokeStyle = '#27ae60';
  ctx.lineWidth = 3;
  for (let i = 0; i < past.length; i++) {
    const x = getX(i);
    const y = getY(past[i].modalPrice);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();

  // Forecast Price Line (Blue #2980b9)
  const todayIdx = past.length - 1;
  ctx.beginPath();
  ctx.strokeStyle = '#2980b9';
  ctx.lineWidth = 3;
  ctx.moveTo(getX(todayIdx), getY(past[todayIdx].modalPrice));

  for (let j = 0; j < future.length; j++) {
    const idx = todayIdx + 1 + j;
    ctx.lineTo(getX(idx), getY(future[j].modalPrice));
  }
  ctx.stroke();

  // "Today" Label
  ctx.fillStyle = '#27ae60';
  ctx.fillText('TODAY', getX(todayIdx) - 15, padY - 5);
}
