// AgriGreen - Krishi Mandi Price Prediction Platform
// Node.js HTTP & REST API Server with Authentication

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const LOCATIONS = require('./data/locations');
const CROPS = require('./data/crops');
const { SOILS, SEASONS } = require('./data/soils');
const { generatePriceHistoryAndForecast } = require('./services/predictionEngine');
const { getNearbyMandis, VEHICLES } = require('./services/arbitrageEngine');
const { recommendCrops } = require('./services/recommendationEngine');
const { generateSellingPeriodAdvisory } = require('./services/advisoryEngine');
const authService = require('./services/authService');

// Port 3001 preserved as specified by user
const PORT = process.env.PORT || 3001;
const PUBLIC_DIR = path.join(__dirname, 'public');

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  });
  res.end(JSON.stringify(data));
}

function sendJsonWithCookie(res, statusCode, data, cookieHeader) {
  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  };
  if (cookieHeader) {
    headers['Set-Cookie'] = cookieHeader;
  }
  res.writeHead(statusCode, headers);
  res.end(JSON.stringify(data));
}

function getCookie(req, name) {
  const cookieHeader = req.headers.cookie;
  if (!cookieHeader) return null;
  const match = cookieHeader.match(new RegExp('(^|;\\s*)' + name + '=([^;]*)'));
  return match ? decodeURIComponent(match[2]) : null;
}

function getAuthUser(req) {
  const sessionId = getCookie(req, 'agri_session') || 
    (req.headers.authorization && req.headers.authorization.replace(/^Bearer\s+/i, '').trim());
  if (!sessionId) return null;
  return authService.getSession(sessionId);
}

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
      if (body.length > 1e6) { // 1MB max
        req.destroy();
        reject(new Error('Payload too large'));
      }
    });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (err) {
        resolve({});
      }
    });
    req.on('error', reject);
  });
}

function serveStaticFile(res, filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const contentType = MIME_TYPES[ext] || 'application/octet-stream';

  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('404 Page Not Found');
      } else {
        res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end(`Server Error: ${err.code}`);
      }
    } else {
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content);
    }
  });
}

const server = http.createServer(async (req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;

  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    });
    res.end();
    return;
  }

  try {
    // ----------------------------------------------------------------
    // 1. Authentication API Endpoints
    // ----------------------------------------------------------------
    if (pathname === '/api/auth/register' && req.method === 'POST') {
      const body = await parseBody(req);
      const result = authService.registerUser(body);
      if (!result.success) {
        sendJson(res, 400, { error: result.error });
        return;
      }
      sendJson(res, 201, { success: true, message: 'Registration successful! Please sign in.', user: result.user });
      return;
    }

    if (pathname === '/api/auth/login' && req.method === 'POST') {
      const body = await parseBody(req);
      const result = authService.loginUser(body);
      if (!result.success) {
        sendJson(res, 401, { error: result.error });
        return;
      }
      const maxAge = body.rememberMe ? (7 * 24 * 60 * 60) : (24 * 60 * 60);
      const cookieStr = `agri_session=${result.sessionId}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}`;
      sendJsonWithCookie(res, 200, { success: true, user: result.user, sessionId: result.sessionId }, cookieStr);
      return;
    }

    if (pathname === '/api/auth/logout' && req.method === 'POST') {
      const sessionId = getCookie(req, 'agri_session');
      if (sessionId) {
        authService.destroySession(sessionId);
      }
      const clearCookie = `agri_session=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; HttpOnly; SameSite=Lax`;
      sendJsonWithCookie(res, 200, { success: true, message: 'Logged out successfully' }, clearCookie);
      return;
    }

    if (pathname === '/api/auth/me' && req.method === 'GET') {
      const userSession = getAuthUser(req);
      if (!userSession) {
        sendJson(res, 200, { authenticated: false });
        return;
      }
      sendJson(res, 200, {
        authenticated: true,
        user: {
          id: userSession.userId,
          fullName: userSession.fullName,
          email: userSession.email,
          mobile: userSession.mobile
        }
      });
      return;
    }

    // ----------------------------------------------------------------
    // 2. Existing Agriculture Data & Analysis Endpoints (Preserved)
    // ----------------------------------------------------------------
    if (pathname === '/api/health') {
      sendJson(res, 200, { status: 'healthy', port: PORT, timestamp: new Date().toISOString() });
      return;
    }

    if (pathname === '/api/metadata' && req.method === 'GET') {
      sendJson(res, 200, {
        states: LOCATIONS.states,
        crops: CROPS.map(c => ({
          id: c.id,
          name: c.name,
          nameHi: c.nameHi,
          category: c.category,
          categoryHi: c.categoryHi,
          msp: c.msp2025 || c.msp2024 || 0,
          baseModalPrice: c.baseModalPrice
        })),
        soils: SOILS,
        seasons: SEASONS,
        vehicles: VEHICLES
      });
      return;
    }

    if (pathname === '/api/mandi/current' && (req.method === 'POST' || req.method === 'GET')) {
      const params = req.method === 'POST' ? await parseBody(req) : parsedUrl.query;
      const cropId = params.cropId || 'wheat';
      const mandiId = params.mandiId || 'MH-NAS-LAS';
      const priceData = generatePriceHistoryAndForecast(cropId, mandiId);
      sendJson(res, 200, {
        crop: priceData.crop,
        currentPrices: priceData.currentPrices,
        forecastSummary: priceData.forecastSummary
      });
      return;
    }

    if (pathname === '/api/mandi/forecast' && (req.method === 'POST' || req.method === 'GET')) {
      const params = req.method === 'POST' ? await parseBody(req) : parsedUrl.query;
      const cropId = params.cropId || 'wheat';
      const mandiId = params.mandiId || 'MH-NAS-LAS';
      const priceData = generatePriceHistoryAndForecast(cropId, mandiId);
      sendJson(res, 200, priceData);
      return;
    }

    if (pathname === '/api/mandi/nearby' && (req.method === 'POST' || req.method === 'GET')) {
      const params = req.method === 'POST' ? await parseBody(req) : parsedUrl.query;
      const stateId = params.stateId || 'MH';
      const districtId = params.districtId || 'MH-NAS';
      const mandiId = params.mandiId || 'MH-NAS-LAS';
      const cropId = params.cropId || 'onion';
      const vehicleType = params.vehicleType || 'pickup';
      const loadQuintals = Number(params.loadQuintals) || 25;

      const nearbyData = getNearbyMandis(stateId, districtId, mandiId, cropId, vehicleType, loadQuintals);
      sendJson(res, 200, nearbyData);
      return;
    }

    if (pathname === '/api/crop/recommend' && (req.method === 'POST' || req.method === 'GET')) {
      const params = req.method === 'POST' ? await parseBody(req) : parsedUrl.query;
      const result = recommendCrops({
        stateId: params.stateId || 'MH',
        soilType: params.soilType || 'Black',
        season: params.season || 'Rabi',
        landSizeAcres: Number(params.landSizeAcres) || 5,
        irrigation: params.irrigation || 'Tube-well',
        budget: params.budget || 'Moderate'
      });
      sendJson(res, 200, result);
      return;
    }

    if (pathname === '/api/insights/selling-period' && (req.method === 'POST' || req.method === 'GET')) {
      const params = req.method === 'POST' ? await parseBody(req) : parsedUrl.query;
      const cropId = params.cropId || 'wheat';
      const mandiId = params.mandiId || 'MH-NAS-LAS';
      const storageOption = params.storageOption || 'warehouse';
      const holdingTargetDays = Number(params.holdingTargetDays) || 30;

      const advisory = generateSellingPeriodAdvisory(cropId, mandiId, storageOption, holdingTargetDays);
      sendJson(res, 200, advisory);
      return;
    }

    // ----------------------------------------------------------------
    // 3. Page Routing & Protection (First page is Login if unauthenticated)
    // ----------------------------------------------------------------

    // Root URL / or /index.html: Protected dashboard route
    if (pathname === '/' || pathname === '/index.html') {
      const user = getAuthUser(req);
      if (!user) {
        // Not logged in -> Redirect immediately to login.html
        res.writeHead(302, { 'Location': '/login.html' });
        res.end();
        return;
      }
      // Authenticated -> Serve AgriGreen dashboard
      serveStaticFile(res, path.join(PUBLIC_DIR, 'index.html'));
      return;
    }

    // /dashboard: Protected dashboard route
    if (pathname === '/dashboard' || pathname === '/dashboard.html') {
      const user = getAuthUser(req);
      if (!user) {
        res.writeHead(302, { 'Location': '/login.html' });
        res.end();
        return;
      }
      serveStaticFile(res, path.join(PUBLIC_DIR, 'index.html'));
      return;
    }

    // /login or /login.html
    if (pathname === '/login' || pathname === '/login.html') {
      const user = getAuthUser(req);
      if (user) {
        // Already logged in -> Redirect to dashboard
        res.writeHead(302, { 'Location': '/dashboard' });
        res.end();
        return;
      }
      serveStaticFile(res, path.join(PUBLIC_DIR, 'login.html'));
      return;
    }

    // /register or /register.html
    if (pathname === '/register' || pathname === '/register.html') {
      const user = getAuthUser(req);
      if (user) {
        res.writeHead(302, { 'Location': '/dashboard' });
        res.end();
        return;
      }
      serveStaticFile(res, path.join(PUBLIC_DIR, 'register.html'));
      return;
    }

    // ----------------------------------------------------------------
    // 4. Other Static Assets (CSS, JS, Images, Icons)
    // ----------------------------------------------------------------
    let safePath = path.normalize(pathname).replace(/^(\.\.[\/\\])+/, '');
    const filePath = path.join(PUBLIC_DIR, safePath);
    serveStaticFile(res, filePath);

  } catch (err) {
    console.error('Unhandled request error:', err);
    sendJson(res, 500, { error: 'Internal Server Error', message: err.message });
  }
});

if (require.main === module) {
  server.listen(PORT, () => {
    console.log(`🌾 AgriGreen Platform Server running at http://localhost:${PORT}`);
  });
}

module.exports = server;
