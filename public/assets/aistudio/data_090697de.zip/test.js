// Automated Unit & Logic Tests for AgriGreen Krishi Mandi Platform
const assert = require('assert');
const fs = require('fs');
const path = require('path');

const LOCATIONS = require('./data/locations');
const CROPS = require('./data/crops');
const { SOILS, SEASONS } = require('./data/soils');
const { generatePriceHistoryAndForecast } = require('./services/predictionEngine');
const { getNearbyMandis } = require('./services/arbitrageEngine');
const { recommendCrops } = require('./services/recommendationEngine');
const { generateSellingPeriodAdvisory } = require('./services/advisoryEngine');
const authService = require('./services/authService');

console.log('🧪 Starting AgriGreen Platform Verification Tests...\n');

// 1. Data Integrity Tests
console.log('1. Checking Data Integrity:');
assert(LOCATIONS.states.length >= 8, 'Must have at least 8 agricultural states');
console.log(`  ✓ Loaded ${LOCATIONS.states.length} states with complete district and mandi mappings`);

assert(CROPS.length >= 10, 'Must have at least 10 core Indian crops');
const wheat = CROPS.find(c => c.id === 'wheat');
assert(wheat && wheat.msp2025 > 0, 'Wheat must have valid MSP benchmark');
console.log(`  ✓ Loaded ${CROPS.length} agricultural crops with MSP and agronomic parameters`);

assert(SOILS.length >= 5, 'Must have at least 5 Indian soil classifications');
assert(SEASONS.length === 3, 'Must have Kharif, Rabi, and Zaid seasons');
console.log(`  ✓ Loaded ${SOILS.length} soil types and 3 cropping seasons`);

// 2. Prediction Engine Tests
console.log('\n2. Testing Predictive Forecasting Engine:');
const forecastResult = generatePriceHistoryAndForecast('wheat', 'PB-LUD-KHA');
assert(forecastResult.currentPrices.modalPrice > 0, 'Modal price must be positive');
assert(forecastResult.historyPoints.length >= 30, 'Should return at least 30 historical points');
assert(forecastResult.forecastPoints.length === 90, 'Should forecast 90 days ahead');
assert(forecastResult.forecastSummary.milestones.day30.modalPrice > 0, '30-day forecast must exist');
console.log(`  ✓ Current Wheat modal price at Khanna APMC: ₹${forecastResult.currentPrices.modalPrice}/Qtl`);
console.log(`  ✓ 30-Day Predicted Price: ₹${forecastResult.forecastSummary.milestones.day30.modalPrice}/Qtl`);
console.log(`  ✓ Trajectory: ${forecastResult.forecastSummary.trajectory} (${forecastResult.forecastSummary.change30DaysPercent}%)`);

// 3. Nearby Arbitrage Engine Tests
console.log('\n3. Testing Nearby Market Transport Arbitrage:');
const arbitrage = getNearbyMandis('MH', 'MH-NAS', 'MH-NAS-LAS', 'onion', 'pickup', 30);
assert(arbitrage.allMandis.length > 0, 'Should return nearby mandis');
assert(arbitrage.bestMandi, 'Must identify best profit mandi');
assert(arbitrage.bestMandi.netRealizedPrice > 0, 'Net realized price must be positive');
console.log(`  ✓ Home Mandi: ${arbitrage.homeMandi.name}`);
console.log(`  ✓ Best Profit Mandi: ${arbitrage.bestMandi.name} (${arbitrage.bestMandi.distanceKm} km)`);
console.log(`  ✓ Net Realized Price: ₹${arbitrage.bestMandi.netRealizedPrice}/Qtl`);

// 4. Crop Recommendation Tests
console.log('\n4. Testing AI Crop Recommendation Engine:');
const rec = recommendCrops({
  stateId: 'MH',
  soilType: 'Black',
  season: 'Kharif',
  landSizeAcres: 5,
  irrigation: 'Tube-well',
  budget: 'Moderate'
});
assert(rec.topCrops.length === 5, 'Should return top 5 ranked crops');
assert(rec.topCrops[0].score >= 70, 'Top recommended crop should have high score');
console.log(`  ✓ Rank #1 Crop for Black Soil in Kharif: ${rec.topCrops[0].name} (${rec.topCrops[0].score}% match)`);

// 5. Selling Period Advisory Tests
console.log('\n5. Testing AI Selling Period (Sell vs Hold) Engine:');
const adv = generateSellingPeriodAdvisory('onion', 'MH-NAS-LAS', 'warehouse', 30);
assert(adv.verdict, 'Must provide an action verdict');
assert(adv.financials.totalCarryingCost > 0, 'Carrying cost must be calculated');
console.log(`  ✓ Action Verdict for Onion: ${adv.titleEn}`);
console.log(`  ✓ Carrying Cost per Quintal: ₹${adv.financials.totalCarryingCost}`);

// 6. Authentication & Session Security Tests
console.log('\n6. Testing Farmer Authentication System:');
const testFarmer = {
  fullName: 'Ramesh Patel',
  mobile: '9876543210',
  email: `farmer_test_${Date.now()}@agrigreen.org`,
  password: 'Password@123',
  confirmPassword: 'Password@123'
};

// 6a. Register user
const regResult = authService.registerUser(testFarmer);
assert(regResult.success === true, 'Farmer registration should succeed');
assert(regResult.user.email === testFarmer.email.toLowerCase(), 'Email should match');
console.log(`  ✓ Farmer registration successful for: ${testFarmer.email}`);

// 6b. Duplicate registration prevention
const dupResult = authService.registerUser(testFarmer);
assert(dupResult.success === false, 'Duplicate registration must be rejected');
console.log('  ✓ Duplicate registration rejected properly');

// 6c. Login with incorrect password
const badLogin = authService.loginUser({ email: testFarmer.email, password: 'WrongPassword' });
assert(badLogin.success === false, 'Bad credentials must be rejected');
console.log('  ✓ Invalid password rejected properly');

// 6d. Login with correct credentials
const goodLogin = authService.loginUser({ email: testFarmer.email, password: testFarmer.password, rememberMe: true });
assert(goodLogin.success === true, 'Valid login must succeed');
assert(goodLogin.sessionId, 'Session ID must be generated');
console.log(`  ✓ Login successful, generated session token: ${goodLogin.sessionId.substring(0, 12)}...`);

// 6e. Session validation
const session = authService.getSession(goodLogin.sessionId);
assert(session && session.email === testFarmer.email.toLowerCase(), 'Session must be active and valid');
console.log('  ✓ Session retrieved and authenticated');

// 6f. Logout & Session destruction
authService.destroySession(goodLogin.sessionId);
const destroyedSession = authService.getSession(goodLogin.sessionId);
assert(destroyedSession === null, 'Session must be destroyed upon logout');
console.log('  ✓ Session destroyed on logout successfully');

// 7. UI, Templates & Port Tests
console.log('\n7. Checking Pages & Template Integrity:');
const html = fs.readFileSync(path.join(__dirname, 'public', 'index.html'), 'utf8');
const loginHtml = fs.readFileSync(path.join(__dirname, 'public', 'login.html'), 'utf8');
const regHtml = fs.readFileSync(path.join(__dirname, 'public', 'register.html'), 'utf8');
const css = fs.readFileSync(path.join(__dirname, 'public', 'css', 'style.css'), 'utf8');
const appJs = fs.readFileSync(path.join(__dirname, 'public', 'js', 'app.js'), 'utf8');
const serverCode = fs.readFileSync(path.join(__dirname, 'server.js'), 'utf8');

assert(loginHtml.includes('Welcome Back'), 'Login page must have Welcome Back heading');
assert(loginHtml.includes('login-email') && loginHtml.includes('login-password'), 'Login form fields present');
assert(regHtml.includes('Farmer Registration'), 'Registration page must have title');
assert(regHtml.includes('reg-name') && regHtml.includes('reg-mobile'), 'Registration fields present');
assert(html.includes('farmer-name-display'), 'Dashboard must display farmer name');
assert(html.includes('btn-logout'), 'Dashboard must have logout button');
assert(serverCode.includes('PORT = process.env.PORT || 3001'), 'Server must use port 3001');
console.log('  ✓ Login and Register pages, Logout button, and Port 3001 verified.');

console.log('\n🎉 ALL TESTS PASSED! AgriGreen Authentication and Dashboard are verified.');
