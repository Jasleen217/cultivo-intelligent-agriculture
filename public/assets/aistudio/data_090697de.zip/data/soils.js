// Soil Types & Characteristics Dataset for Indian Agriculture
// Used for crop suitability algorithms, nutrient recommendations, and irrigation adjustments

const SOILS = [
  {
    id: "Alluvial",
    name: "Alluvial Soil (Khadar & Bhangar)",
    nameHi: "जलोढ़ मिट्टी",
    description: "Formed by river silt deposits; rich in potash and lime, moderate in phosphorus, deficient in nitrogen and organic humus.",
    descriptionHi: "नदियों द्वारा लाई गई उपजाऊ मिट्टी; पोटाश और चूने से भरपूर, नाइट्रोजन की कमी। गेहूं, धान, गन्ना और मक्का के लिए सर्वोत्तम।",
    phRange: "6.5 - 8.2",
    waterRetention: "High to Moderate",
    drainage: "Good",
    recommendedCrops: ["wheat", "paddy", "mustard", "potato", "maize", "garlic", "onion"],
    organicMatterAdjustment: "Apply 8-10 tonnes/acre Well-decomposed Farmyard Manure (FYM) or vermicompost before tilling.",
    irrigationSuitability: ["Canal", "Tube-well", "Drip/Sprinkler", "Rainfed"],
    regions: ["Indo-Gangetic Plains", "Punjab", "Haryana", "UP", "Bihar", "West Bengal", "Deltaic regions"]
  },
  {
    id: "Black",
    name: "Black Soil (Regur / Clayey)",
    nameHi: "काली मिट्टी (रेगुर)",
    description: "Formed from volcanic basalt; high clay fraction, self-ploughing capacity with deep cracks in summer, high moisture retention.",
    descriptionHi: "ज्वालामुखीय लावा से निर्मित; नमी को लंबे समय तक रोकती है। कपास, सोयाबीन, चना, गेहूं और तुअर के लिए आदर्श।",
    phRange: "7.5 - 8.5",
    waterRetention: "Very High",
    drainage: "Moderate to Poor (risk of waterlogging in heavy downpours)",
    recommendedCrops: ["cotton", "soybean", "gram", "wheat", "tur", "chilli", "garlic"],
    organicMatterAdjustment: "Requires deep summer ploughing. Add gypsum if soil turns excessively sodic.",
    irrigationSuitability: ["Tube-well", "Drip/Sprinkler", "Rainfed"],
    regions: ["Deccan Plateau", "Maharashtra", "Madhya Pradesh", "Gujarat", "Northern Karnataka"]
  },
  {
    id: "Red & Yellow",
    name: "Red & Yellow Soil",
    nameHi: "लाल और पीली मिट्टी",
    description: "Developed over crystalline igneous rocks; rich in iron oxides giving reddish hue, porous, low nitrogen and humus.",
    descriptionHi: "लोहे के अंश के कारण लाल रंग; जल निकासी तेज होती है। मूंगफली, मक्का, दालें, और सब्जियों के लिए उपयुक्त।",
    phRange: "5.5 - 7.0",
    waterRetention: "Low to Moderate",
    drainage: "Rapid / Excessive",
    recommendedCrops: ["groundnut", "maize", "tur", "tomato", "chilli", "cotton"],
    organicMatterAdjustment: "Needs heavy green manuring (Dhaincha/Sunhemp) and micro-dosing of phosphorus & zinc.",
    irrigationSuitability: ["Drip/Sprinkler", "Tube-well", "Rainfed"],
    regions: ["Eastern Deccan", "Tamil Nadu", "Karnataka", "Andhra Pradesh", "Odisha", "Chota Nagpur"]
  },
  {
    id: "Clayey Loam",
    name: "Clayey Loam (Do-mat)",
    nameHi: "दोमट मिट्टी",
    description: "Optimal balance of sand, silt, and clay (40-40-20); highest nutrient exchange capacity and ideal root aeration.",
    descriptionHi: "रेत, गाद और चिकनी मिट्टी का संतुलित मिश्रण; अधिकांश फसलों व सब्जियों के लिए सबसे आदर्श मिट्टी।",
    phRange: "6.2 - 7.5",
    waterRetention: "High",
    drainage: "Excellent",
    recommendedCrops: ["onion", "garlic", "tomato", "wheat", "potato", "mustard", "soybean", "paddy"],
    organicMatterAdjustment: "Maintain regular crop rotation with leguminous green manure crops every 2-3 seasons.",
    irrigationSuitability: ["Canal", "Tube-well", "Drip/Sprinkler", "Rainfed"],
    regions: ["Central Plains", "Valley basins", "Maharashtra", "Madhya Pradesh", "Punjab"]
  },
  {
    id: "Sandy Loam",
    name: "Sandy Loam / Arid Soil",
    nameHi: "बलुई दोमट / रेतीली मिट्टी",
    description: "High sand proportion; loose aggregate, quick warming, low cation exchange capacity, requires frequent light irrigation.",
    descriptionHi: "रेत का अधिक अनुपात; पानी जल्दी सोखती है। सरसों, चना, मूंगफली, आलू और तरबूज के लिए बेहतरीन।",
    phRange: "7.0 - 8.8",
    waterRetention: "Low",
    drainage: "Very Fast",
    recommendedCrops: ["mustard", "gram", "groundnut", "potato", "maize"],
    organicMatterAdjustment: "High mulch requirement to curb surface moisture evaporation. Incorporate bio-char and press mud.",
    irrigationSuitability: ["Drip/Sprinkler", "Tube-well"],
    regions: ["Western Rajasthan", "Southern Punjab", "Southern Haryana", "Kutch"]
  },
  {
    id: "Laterite",
    name: "Laterite Soil",
    nameHi: "लेटराइट मिट्टी",
    description: "Formed under alternating wet and dry tropical conditions; intense leaching leaves residual bauxite and iron.",
    descriptionHi: "अधिक वर्षा से पोषक तत्वों के बह जाने से बनी मिट्टी; अम्लीय प्रकृति। काजू, रबर, दालें व नियंत्रित सिंचाई वाली फसलें।",
    phRange: "4.8 - 6.2 (Acidic)",
    waterRetention: "Low",
    drainage: "Fast",
    recommendedCrops: ["tur", "groundnut", "maize", "chilli"],
    organicMatterAdjustment: "Lime application (Agricultural limestone @ 1-2 tonnes/ha) necessary to neutralize acidity.",
    irrigationSuitability: ["Drip/Sprinkler", "Rainfed"],
    regions: ["Western Ghats", "Eastern Ghats", "Coastal Karnataka", "Kerala", "Assam hills"]
  }
];

const SEASONS = [
  {
    id: "Kharif",
    name: "Kharif (Monsoon Season / खरीफ)",
    sowingPeriod: "June - July",
    harvestPeriod: "October - November",
    weatherTraits: "Warm & humid with high monsoon rainfall",
    typicalCrops: ["paddy", "cotton", "soybean", "maize", "groundnut", "tur", "tomato", "onion"]
  },
  {
    id: "Rabi",
    name: "Rabi (Winter Season / रबी)",
    sowingPeriod: "October - December",
    harvestPeriod: "March - April",
    weatherTraits: "Cool, dry weather with bright sunshine and cold nights",
    typicalCrops: ["wheat", "mustard", "gram", "potato", "garlic", "onion", "chilli"]
  },
  {
    id: "Zaid",
    name: "Zaid / Summer (जायद / ग्रीष्म)",
    sowingPeriod: "March - April",
    harvestPeriod: "May - June",
    weatherTraits: "Hot, dry summer requiring reliable assured irrigation",
    typicalCrops: ["maize", "groundnut", "tomato", "vegetables"]
  }
];

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { SOILS, SEASONS };
}
