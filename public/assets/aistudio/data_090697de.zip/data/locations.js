// Comprehensive Indian Mandi & Location Dataset
// Covering major agricultural states, key APMC markets, and geographic linkages

const LOCATIONS = {
  states: [
    {
      id: "MH",
      name: "Maharashtra",
      nameHi: "महाराष्ट्र",
      districts: [
        {
          id: "MH-NAS",
          name: "Nashik",
          nameHi: "नाशिक",
          mandis: [
            { id: "MH-NAS-LAS", name: "Lasalgaon APMC", nameHi: "लासलगांव मंडी", type: "Major Onion & Grain Hub", lat: 20.147, lon: 74.225, distanceOffset: 0 },
            { id: "MH-NAS-PIM", name: "Pimpalgaon APMC", nameHi: "पिंपलगांव मंडी", type: "Tomato & Vegetable Hub", lat: 20.169, lon: 73.987, distanceOffset: 28 },
            { id: "MH-NAS-YEO", name: "Yeola APMC", nameHi: "येवला मंडी", type: "Grain & Onion Market", lat: 20.042, lon: 74.489, distanceOffset: 34 },
            { id: "MH-NAS-MAL", name: "Malegaon APMC", nameHi: "मालेगांव मंडी", type: "Cotton & Grain Market", lat: 20.553, lon: 74.529, distanceOffset: 52 }
          ]
        },
        {
          id: "MH-PUN",
          name: "Pune",
          nameHi: "पुणे",
          mandis: [
            { id: "MH-PUN-GUL", name: "Pune APMC (Gultekdi)", nameHi: "पुणे मंडी (गुलटेकड़ी)", type: "Terminal Metro APMC", lat: 18.498, lon: 73.864, distanceOffset: 0 },
            { id: "MH-PUN-BAR", name: "Baramati APMC", nameHi: "बारामती मंडी", type: "Sugarcane & Grain Hub", lat: 18.151, lon: 74.577, distanceOffset: 95 },
            { id: "MH-PUN-MAN", name: "Manchar APMC", nameHi: "मंचर मंडी", type: "Vegetable & Potato Market", lat: 19.002, lon: 73.945, distanceOffset: 62 }
          ]
        },
        {
          id: "MH-NAG",
          name: "Nagpur",
          nameHi: "नागपुर",
          mandis: [
            { id: "MH-NAG-KAL", name: "Kalamna APMC", nameHi: "कलमना मंडी", type: "Orange & Soybean Terminal", lat: 21.178, lon: 79.141, distanceOffset: 0 },
            { id: "MH-NAG-KAT", name: "Katol APMC", nameHi: "काटोल मंडी", type: "Citrus & Cotton Market", lat: 21.268, lon: 78.587, distanceOffset: 58 },
            { id: "MH-NAG-SAO", name: "Saoner APMC", nameHi: "सावनेर मंडी", type: "Grain & Pulse Market", lat: 21.385, lon: 78.917, distanceOffset: 42 }
          ]
        },
        {
          id: "MH-AHM",
          name: "Ahmednagar",
          nameHi: "अहमदनगर",
          mandis: [
            { id: "MH-AHM-RAH", name: "Rahuri APMC", nameHi: "राहुरी मंडी", type: "Agri University Hub & Grain", lat: 19.394, lon: 74.651, distanceOffset: 0 },
            { id: "MH-AHM-SAN", name: "Sangamner APMC", nameHi: "संगमनेर मंडी", type: "Dairy, Onion & Tomato", lat: 19.571, lon: 74.209, distanceOffset: 48 },
            { id: "MH-AHM-KOP", name: "Kopargaon APMC", nameHi: "कोपरगांव मंडी", type: "Sugarcane & Maize Hub", lat: 19.892, lon: 74.481, distanceOffset: 65 }
          ]
        },
        {
          id: "MH-SOL",
          name: "Solapur",
          nameHi: "सोलापूर",
          mandis: [
            { id: "MH-SOL-SOL", name: "Solapur APMC", nameHi: "सोलापूर मंडी", type: "Pomegranate & Pulse Market", lat: 17.659, lon: 75.906, distanceOffset: 0 },
            { id: "MH-SOL-KUR", name: "Kurduvadi APMC", nameHi: "कुर्डूवाडी मंडी", type: "Jowar & Grain Market", lat: 18.087, lon: 75.433, distanceOffset: 72 }
          ]
        }
      ]
    },
    {
      id: "MP",
      name: "Madhya Pradesh",
      nameHi: "मध्य प्रदेश",
      districts: [
        {
          id: "MP-IND",
          name: "Indore",
          nameHi: "इंदौर",
          mandis: [
            { id: "MP-IND-CHO", name: "Indore APMC (Choithram)", nameHi: "इंदौर मंडी (चोइथराम)", type: "Central Soybean & Wheat Terminal", lat: 22.685, lon: 75.842, distanceOffset: 0 },
            { id: "MP-IND-SAN", name: "Sanwer APMC", nameHi: "सांवेर मंडी", type: "Wheat & Pulse Market", lat: 22.977, lon: 75.825, distanceOffset: 32 },
            { id: "MP-IND-MHO", name: "Mhow APMC", nameHi: "महू मंडी", type: "Potato & Garlic Market", lat: 22.553, lon: 75.764, distanceOffset: 25 }
          ]
        },
        {
          id: "MP-UJJ",
          name: "Ujjain",
          nameHi: "उज्जैन",
          mandis: [
            { id: "MP-UJJ-UJJ", name: "Ujjain APMC (Chimanbagh)", nameHi: "उज्जैन मंडी", type: "Major Soybean & Gram Market", lat: 23.176, lon: 75.788, distanceOffset: 0 },
            { id: "MP-UJJ-MAH", name: "Mahidpur APMC", nameHi: "महिदपुर मंडी", type: "Wheat & Mustard Market", lat: 23.486, lon: 75.658, distanceOffset: 55 }
          ]
        },
        {
          id: "MP-SEH",
          name: "Sehore",
          nameHi: "सीहोर",
          mandis: [
            { id: "MP-SEH-SEH", name: "Sehore APMC", nameHi: "सीहोर मंडी", type: "Famous Sharbati Wheat Hub", lat: 23.203, lon: 77.084, distanceOffset: 0 },
            { id: "MP-SEH-ASH", name: "Ashta APMC", nameHi: "आष्टा मंडी", type: "Soybean & Grain Market", lat: 23.020, lon: 76.721, distanceOffset: 45 }
          ]
        },
        {
          id: "MP-MAN",
          name: "Mandsaur",
          nameHi: "मंदसौर",
          mandis: [
            { id: "MP-MAN-MAN", name: "Mandsaur APMC", nameHi: "मंदसौर मंडी", type: "Garlic, Mustard & Coriander Hub", lat: 24.072, lon: 75.069, distanceOffset: 0 },
            { id: "MP-MAN-PIP", name: "Piplia APMC", nameHi: "पिपलिया मंडी", type: "Garlic & Spice Market", lat: 24.218, lon: 75.012, distanceOffset: 22 }
          ]
        }
      ]
    },
    {
      id: "PB",
      name: "Punjab",
      nameHi: "पंजाब",
      districts: [
        {
          id: "PB-LUD",
          name: "Ludhiana",
          nameHi: "लुधियाना",
          mandis: [
            { id: "PB-LUD-KHA", name: "Khanna APMC", nameHi: "खन्ना मंडी", type: "Asia's Largest Grain Market", lat: 30.706, lon: 76.221, distanceOffset: 0 },
            { id: "PB-LUD-JAG", name: "Jagraon APMC", nameHi: "जgraon मंडी", type: "Paddy & Wheat Market", lat: 30.785, lon: 75.478, distanceOffset: 42 },
            { id: "PB-LUD-CIT", name: "Ludhiana APMC", nameHi: "लुधियाना मंडी", type: "Metro Grain Terminal", lat: 30.901, lon: 75.857, distanceOffset: 38 }
          ]
        },
        {
          id: "PB-AMR",
          name: "Amritsar",
          nameHi: "अमृतसर",
          mandis: [
            { id: "PB-AMR-BHAG", name: "Amritsar APMC (Bhagtanwala)", nameHi: "अमृतसर मंडी", type: "Basmati Rice Terminal", lat: 31.634, lon: 74.872, distanceOffset: 0 },
            { id: "PB-AMR-RAY", name: "Rayya APMC", nameHi: "रय्या मंडी", type: "Paddy & Wheat Hub", lat: 31.536, lon: 75.167, distanceOffset: 36 }
          ]
        },
        {
          id: "PB-BAT",
          name: "Bathinda",
          nameHi: "बठिंडा",
          mandis: [
            { id: "PB-BAT-BAT", name: "Bathinda APMC", nameHi: "बठिंडा मंडी", type: "Cotton & Wheat Hub", lat: 30.211, lon: 74.945, distanceOffset: 0 },
            { id: "PB-BAT-RAM", name: "Rampura Phul APMC", nameHi: "रामपुरा फूल मंडी", type: "Cotton & Mustard Hub", lat: 30.272, lon: 75.239, distanceOffset: 34 }
          ]
        }
      ]
    },
    {
      id: "HR",
      name: "Haryana",
      nameHi: "हरियाणा",
      districts: [
        {
          id: "HR-KAR",
          name: "Karnal",
          nameHi: "करनाल",
          mandis: [
            { id: "HR-KAR-KAR", name: "Karnal New Grain Market", nameHi: "करनाल नई अनाज मंडी", type: "Basmati Rice Capital", lat: 29.685, lon: 76.990, distanceOffset: 0 },
            { id: "HR-KAR-TAR", name: "Taraori APMC", nameHi: "तरावड़ी मंडी", type: "Export Basmati Hub", lat: 29.803, lon: 76.928, distanceOffset: 18 },
            { id: "HR-KAR-GHA", name: "Gharaunda APMC", nameHi: "घरौंडा मंडी", type: "Vegetable & Wheat Center", lat: 29.539, lon: 76.971, distanceOffset: 20 }
          ]
        },
        {
          id: "HR-SIR",
          name: "Sirsa",
          nameHi: "सिरसा",
          mandis: [
            { id: "HR-SIR-SIR", name: "Sirsa APMC", nameHi: "सिरसा मंडी", type: "Cotton & Mustard Terminal", lat: 29.534, lon: 75.029, distanceOffset: 0 },
            { id: "HR-SIR-ELL", name: "Ellenabad APMC", nameHi: "ऐलनाबाद मंडी", type: "Guar & Mustard Market", lat: 29.452, lon: 74.658, distanceOffset: 43 }
          ]
        },
        {
          id: "HR-HIS",
          name: "Hisar",
          nameHi: "हिसार",
          mandis: [
            { id: "HR-HIS-HIS", name: "Hisar APMC", nameHi: "हिसार मंडी", type: "Wheat, Gram & Cotton Hub", lat: 29.149, lon: 75.721, distanceOffset: 0 },
            { id: "HR-HIS-HAN", name: "Hansi APMC", nameHi: "हांसी मंडी", type: "Grain & Oilseed Market", lat: 29.100, lon: 75.962, distanceOffset: 26 }
          ]
        }
      ]
    },
    {
      id: "UP",
      name: "Uttar Pradesh",
      nameHi: "उत्तर प्रदेश",
      districts: [
        {
          id: "UP-AGR",
          name: "Agra",
          nameHi: "आगरा",
          mandis: [
            { id: "UP-AGR-AGR", name: "Agra APMC (Khandari)", nameHi: "आगरा मंडी", type: "Major Potato & Mustard Hub", lat: 27.176, lon: 78.008, distanceOffset: 0 },
            { id: "UP-AGR-SHA", name: "Shamsabad APMC", nameHi: "शमसाबाद मंडी", type: "Potato Special Mandi", lat: 27.018, lon: 78.125, distanceOffset: 24 },
            { id: "UP-AGR-FAT", name: "Fatehabad APMC", nameHi: "फतेहाबाद मंडी", type: "Grain & Mustard Market", lat: 27.025, lon: 78.312, distanceOffset: 36 }
          ]
        },
        {
          id: "UP-KAN",
          name: "Kanpur",
          nameHi: "कानपुर",
          mandis: [
            { id: "UP-KAN-CHA", name: "Kanpur APMC (Chaubepur)", nameHi: "कानपुर मंडी", type: "Pulse & Wheat Trading Hub", lat: 26.619, lon: 80.170, distanceOffset: 0 },
            { id: "UP-KAN-BIL", name: "Bilhaur APMC", nameHi: "बिल्हौर मंडी", type: "Maize & Potato Market", lat: 26.848, lon: 80.052, distanceOffset: 35 }
          ]
        },
        {
          id: "UP-VAR",
          name: "Varanasi",
          nameHi: "वाराणसी",
          mandis: [
            { id: "UP-VAR-ROH", name: "Rohaniya APMC", nameHi: "रोहनिया मंडी", type: "Eastern UP Grain & Veg Terminal", lat: 25.278, lon: 82.915, distanceOffset: 0 }
          ]
        },
        {
          id: "UP-ALI",
          name: "Aligarh",
          nameHi: "अलीगढ़",
          mandis: [
            { id: "UP-ALI-ALI", name: "Aligarh APMC (Dhaniapur)", nameHi: "अलीगढ़ मंडी", type: "Wheat & Mustard Center", lat: 27.897, lon: 78.088, distanceOffset: 0 },
            { id: "UP-ALI-ATR", name: "Atrauli APMC", nameHi: "अतरौली मंडी", type: "Paddy & Maize Market", lat: 28.030, lon: 78.291, distanceOffset: 28 }
          ]
        }
      ]
    },
    {
      id: "GJ",
      name: "Gujarat",
      nameHi: "गुजरात",
      districts: [
        {
          id: "GJ-RAJ",
          name: "Rajkot",
          nameHi: "राजकोट",
          mandis: [
            { id: "GJ-RAJ-RAJ", name: "Rajkot APMC (Bedi)", nameHi: "राजकोट मंडी (बेड़ी)", type: "Groundnut & Cotton Capital", lat: 22.303, lon: 70.802, distanceOffset: 0 },
            { id: "GJ-RAJ-GON", name: "Gondal APMC", nameHi: "गोंडल मंडी", type: "World Famous Chilli & Groundnut Hub", lat: 21.961, lon: 70.793, distanceOffset: 38 },
            { id: "GJ-RAJ-JAS", name: "Jasdan APMC", nameHi: "जसदन मंडी", type: "Sesame & Cotton Market", lat: 22.035, lon: 71.204, distanceOffset: 55 }
          ]
        },
        {
          id: "GJ-MEH",
          name: "Mehsana",
          nameHi: "मेहसाणा",
          mandis: [
            { id: "GJ-MEH-UNJ", name: "Unjha APMC", nameHi: "ऊंझा मंडी", type: "Asia's Largest Cumin & Spice Market", lat: 23.804, lon: 72.392, distanceOffset: 0 },
            { id: "GJ-MEH-VIS", name: "Visnagar APMC", nameHi: "विसनगर मंडी", type: "Mustard & Castor Market", lat: 23.696, lon: 72.551, distanceOffset: 22 }
          ]
        },
        {
          id: "GJ-AHM",
          name: "Ahmedabad",
          nameHi: "अहमदाबाद",
          mandis: [
            { id: "GJ-AHM-JAM", name: "Ahmedabad APMC (Jamalpur)", nameHi: "अहमदाबाद मंडी", type: "Central Wholesale Hub", lat: 23.013, lon: 72.580, distanceOffset: 0 },
            { id: "GJ-AHM-SAN", name: "Sanand APMC", nameHi: "साणंद मंडी", type: "Wheat & Cotton Market", lat: 22.986, lon: 72.378, distanceOffset: 26 }
          ]
        }
      ]
    },
    {
      id: "RJ",
      name: "Rajasthan",
      nameHi: "राजस्थान",
      districts: [
        {
          id: "RJ-JAI",
          name: "Jaipur",
          nameHi: "जयपुर",
          mandis: [
            { id: "RJ-JAI-MUH", name: "Jaipur APMC (Muhana)", nameHi: "जयपुर मंडी (मुहाना)", type: "Largest Fruits & Veg Terminal", lat: 26.812, lon: 75.760, distanceOffset: 0 },
            { id: "RJ-JAI-CHO", name: "Chomu APMC", nameHi: "चौमूं मंडी", type: "Vegetable & Oilseed Hub", lat: 27.173, lon: 75.722, distanceOffset: 34 }
          ]
        },
        {
          id: "RJ-KOT",
          name: "Kota",
          nameHi: "कोटा",
          mandis: [
            { id: "RJ-KOT-BHAM", name: "Kota APMC (Bhamashah)", nameHi: "कोटा भामाशाह मंडी", type: "Soybean & Mustard Mega Market", lat: 25.180, lon: 75.864, distanceOffset: 0 },
            { id: "RJ-KOT-RAM", name: "Ramganj Mandi", nameHi: "रामगंज मंडी", type: "Asia's Coriander (Dhaniya) Capital", lat: 24.646, lon: 75.945, distanceOffset: 70 }
          ]
        },
        {
          id: "RJ-BIK",
          name: "Bikaner",
          nameHi: "बीकानेर",
          mandis: [
            { id: "RJ-BIK-BIK", name: "Bikaner APMC", nameHi: "बीकानेर मंडी", type: "Guar Gum & Moth Bean Capital", lat: 28.022, lon: 73.311, distanceOffset: 0 },
            { id: "RJ-BIK-NOK", name: "Nokha APMC", nameHi: "नोखा मंडी", type: "Moth Bean & Peanut Hub", lat: 27.601, lon: 73.421, distanceOffset: 58 }
          ]
        }
      ]
    },
    {
      id: "KA",
      name: "Karnataka",
      nameHi: "कर्नाटक",
      districts: [
        {
          id: "KA-DHA",
          name: "Dharwad",
          nameHi: "धारवाड़",
          mandis: [
            { id: "KA-DHA-HUB", name: "Hubli APMC (Amargol)", nameHi: "हुबली मंडी (अमरगोल)", type: "North Karnataka Mega APMC", lat: 15.395, lon: 75.122, distanceOffset: 0 },
            { id: "KA-DHA-BYA", name: "Byadgi APMC", nameHi: "ब्याडगी मंडी", type: "World Famous Byadgi Chilli Hub", lat: 14.680, lon: 75.485, distanceOffset: 85 }
          ]
        },
        {
          id: "KA-BEN",
          name: "Bengaluru Rural",
          nameHi: "बेंगलुरु ग्रामीण",
          mandis: [
            { id: "KA-BEN-YES", name: "Yeshwanthpur APMC", nameHi: "यशवंतपुर मंडी", type: "South India Super Terminal", lat: 13.023, lon: 77.551, distanceOffset: 0 },
            { id: "KA-BEN-NEL", name: "Nelamangala APMC", nameHi: "नेलमंगला मंडी", type: "Vegetable & Flower Hub", lat: 13.098, lon: 77.388, distanceOffset: 25 }
          ]
        }
      ]
    },
    {
      id: "AP",
      name: "Andhra Pradesh",
      nameHi: "आंध्र प्रदेश",
      districts: [
        {
          id: "AP-GUN",
          name: "Guntur",
          nameHi: "गुंटूर",
          mandis: [
            { id: "AP-GUN-MIR", name: "Guntur Mirchi Yard", nameHi: "गुंटूर मिर्ची यार्ड", type: "Asia's Largest Red Chilli Market", lat: 16.306, lon: 80.436, distanceOffset: 0 },
            { id: "AP-GUN-TEN", name: "Tenali APMC", nameHi: "तेनाली मंडी", type: "Paddy & Turmeric Hub", lat: 16.243, lon: 80.640, distanceOffset: 28 }
          ]
        }
      ]
    }
  ]
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = LOCATIONS;
}
